<?php

use App\Http\Controllers\Admin\GuruController;
use App\Http\Controllers\Admin\JadwalController;
use App\Http\Controllers\Admin\KelasController;
use App\Http\Controllers\Admin\OrangTuaController;
use App\Http\Controllers\Admin\QrController;
use App\Http\Controllers\Admin\SiswaController;
use App\Http\Controllers\Admin\SiswaImportController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\OrtuController;
use App\Http\Controllers\PresensiController;
use App\Http\Controllers\RekapController;
use App\Http\Controllers\ValidasiController;
use App\Http\Middleware\RoleMiddleware as R;
use Illuminate\Support\Facades\Route;

Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/fcm-token', [AuthController::class, 'fcmToken']);
    Route::get('/dashboard', [DashboardController::class, 'index']);

    // Guru & wali kelas
   Route::middleware(R::class . ':guru,wali_kelas,admin')->group(function () {
        Route::get('/presensi', [PresensiController::class, 'index']);
        Route::post('/presensi/scan', [PresensiController::class, 'scan']);
        Route::post('/presensi/manual', [PresensiController::class, 'manual']);
    });
    Route::get('/kelas-opsi', [PresensiController::class, 'kelasOpsi'])
        ->middleware(R::class . ':guru,wali_kelas,kepala_sekolah,admin');

    // Wali kelas
    Route::middleware(R::class . ':wali_kelas,admin')->group(function () {
        Route::get('/validasi', [ValidasiController::class, 'index']);
        Route::post('/validasi', [ValidasiController::class, 'store']);
        Route::patch('/presensi/{id}/koreksi', [ValidasiController::class, 'koreksi']);
    });

    // Rekap & ekspor
    Route::get('/rekap', [RekapController::class, 'index'])->middleware(R::class . ':guru,wali_kelas,kepala_sekolah,admin');
    Route::get('/rekap/ekspor', [RekapController::class, 'ekspor'])->middleware(R::class . ':wali_kelas,kepala_sekolah,admin');

    // Orang tua
    Route::middleware(R::class . ':orang_tua')->prefix('ortu')->group(function () {
        Route::get('/anak', [OrtuController::class, 'anak']);
        Route::get('/anak/{siswaId}/rekap', [OrtuController::class, 'rekap']);
        Route::get('/notifikasi', [OrtuController::class, 'notifikasi']);
    });

    // Admin / IT sekolah
    Route::middleware(R::class . ':admin')->group(function () {
        Route::get('/siswa/template', [SiswaImportController::class, 'template']);
        Route::post('/siswa/impor/pratinjau', [SiswaImportController::class, 'pratinjau']);
        Route::post('/siswa/impor', [SiswaImportController::class, 'impor']);
        Route::get('/siswa/{id}/qr', [QrController::class, 'siswa']);
        Route::post('/siswa/{id}/qr/regenerate', [SiswaController::class, 'regenerateQr']);
        Route::get('/qr/kartu', [QrController::class, 'kartu']);

        Route::apiResource('users', UserController::class);
        Route::apiResource('guru', GuruController::class);
        Route::apiResource('orang-tua', OrangTuaController::class);
        Route::apiResource('kelas', KelasController::class);
        Route::apiResource('siswa', SiswaController::class);
        Route::apiResource('jadwal', JadwalController::class);
    });
});
