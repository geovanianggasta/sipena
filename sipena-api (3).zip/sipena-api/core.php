<?php
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . CORS_ORIGIN);
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function db(): PDO
{
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function ok($data = null, string $msg = 'Berhasil', int $code = 200)
{
    http_response_code($code);
    echo json_encode(['status' => 'success', 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function fail(string $msg, int $code = 400, $data = null)
{
    http_response_code($code);
    echo json_encode(['status' => 'error', 'message' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function input(): array
{
    static $d;
    if ($d === null) {
        $d = json_decode(file_get_contents('php://input'), true);
        $d = is_array($d) ? $d : [];
    }
    return $d;
}

function bearer(): ?string
{
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    return preg_match('/^Bearer\s+(\S+)$/i', $h, $m) ? $m[1] : null;
}

function auth(array $roles = []): array
{
    $t = bearer();
    if (!$t) fail('Belum login', 401);
    $u = q('SELECT u.id, u.username, u.nama, u.role FROM sesi s JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = ? AND s.kedaluwarsa > ? AND u.aktif = 1',
        [hash('sha256', $t), date('Y-m-d H:i:s')])->fetch();
    if (!$u) fail('Sesi tidak valid atau sudah berakhir', 401);
    if ($roles && !in_array($u['role'], $roles, true)) fail('Tidak punya akses', 403);
    return $u;
}

function guruId(array $u): int
{
    return (int)q('SELECT id FROM guru WHERE user_id = ?', [$u['id']])->fetchColumn();
}

function kelasWali(array $u): int
{
    return (int)q('SELECT id FROM kelas WHERE wali_kelas_id = (SELECT id FROM guru WHERE user_id = ?) LIMIT 1', [$u['id']])->fetchColumn();
}

function tanggal(?string $s, ?string $default = null): string
{
    if ($s === null || $s === '') return $default ?? date('Y-m-d');
    $d = DateTime::createFromFormat('Y-m-d', $s);
    if (!$d || $d->format('Y-m-d') !== $s) fail('Format tanggal harus YYYY-MM-DD', 422);
    return $s;
}

$GLOBALS['routes'] = [];

function route(string $method, string $path, ?array $roles, callable $fn): void
{
    $re = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', $path) . '$#';
    $GLOBALS['routes'][] = [$method, $re, $roles, $fn];
}

function dispatch(): void
{
    $method = $_SERVER['REQUEST_METHOD'];
    $path = trim($_GET['r'] ?? '', '/');
    try {
        foreach ($GLOBALS['routes'] as [$m, $re, $roles, $fn]) {
            if ($m !== $method || !preg_match($re, $path, $mt)) continue;
            $params = array_filter($mt, 'is_string', ARRAY_FILTER_USE_KEY);
            $user = $roles === null ? null : auth($roles);
            $fn($params, $user);
            return;
        }
        fail('Endpoint tidak ditemukan', 404);
    } catch (PDOException $e) {
        error_log($e->getMessage());
        if ($e->getCode() === '23000') fail('Data duplikat atau masih terkait data lain', 409);
        fail('Kesalahan database', 500);
    } catch (Throwable $e) {
        error_log($e->getMessage());
        fail('Kesalahan server', 500);
    }
}
