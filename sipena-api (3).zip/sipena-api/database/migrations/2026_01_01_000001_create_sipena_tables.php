<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('guru', function (Blueprint $t) {
            $t->id();
            $t->string('nip', 30)->unique();
            $t->string('nama');
            $t->string('mata_pelajaran')->nullable();
            $t->string('kontak', 30)->nullable();
            $t->foreignId('user_id')->nullable()->unique()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('orang_tua', function (Blueprint $t) {
            $t->id();
            $t->string('nama');
            $t->string('hubungan', 30)->nullable();
            $t->string('no_hp', 30)->nullable();
            $t->string('alamat')->nullable();
            $t->foreignId('user_id')->nullable()->unique()->constrained('users')->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('kelas', function (Blueprint $t) {
            $t->id();
            $t->string('nama_kelas', 30)->unique();
            $t->unsignedTinyInteger('tingkat');
            $t->foreignId('wali_kelas_id')->nullable()->constrained('guru')->nullOnDelete();
            $t->string('tahun_ajaran', 9);
            $t->timestamps();
        });

        Schema::create('siswa', function (Blueprint $t) {
            $t->id();
            $t->string('nisn', 20)->unique();
            $t->string('nama');
            $t->foreignId('kelas_id')->constrained('kelas')->restrictOnDelete();
            $t->foreignId('ortu_id')->nullable()->constrained('orang_tua')->nullOnDelete();
            $t->string('qr_code', 64)->unique();
            $t->timestamps();
        });

        Schema::create('jadwal', function (Blueprint $t) {
            $t->id();
            $t->foreignId('kelas_id')->constrained('kelas')->restrictOnDelete();
            $t->foreignId('guru_id')->constrained('guru')->restrictOnDelete();
            $t->string('mata_pelajaran');
            $t->string('hari', 10);
            $t->time('jam_mulai');
            $t->time('jam_selesai');
            $t->timestamps();
        });

        Schema::create('presensi', function (Blueprint $t) {
            $t->id();
            $t->foreignId('siswa_id')->constrained('siswa')->restrictOnDelete();
            $t->foreignId('jadwal_id')->nullable()->constrained('jadwal')->restrictOnDelete();
            $t->date('tanggal');
            $t->time('waktu_scan')->nullable();
            $t->string('status', 10);
            $t->string('keterangan')->nullable();
            $t->boolean('status_validasi')->default(false);
            $t->foreignId('validated_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamp('validated_at')->nullable();
            $t->timestamps();
            $t->unique(['siswa_id', 'tanggal']);
            $t->index(['tanggal', 'status']);
        });

        Schema::create('notifikasi', function (Blueprint $t) {
            $t->id();
            $t->foreignId('siswa_id')->nullable()->constrained('siswa')->nullOnDelete();
            $t->foreignId('ortu_id')->nullable()->constrained('orang_tua')->nullOnDelete();
            $t->text('pesan');
            $t->dateTime('tanggal');
            $t->string('status_kirim', 10);
            $t->timestamps();
        });

        Schema::create('log_perubahan', function (Blueprint $t) {
            $t->id();
            $t->foreignId('presensi_id')->constrained('presensi')->cascadeOnDelete();
            $t->foreignId('pengguna_id')->nullable()->constrained('users')->nullOnDelete();
            $t->dateTime('waktu');
            $t->string('status_lama', 10);
            $t->string('status_baru', 10);
            $t->string('alasan');
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['log_perubahan', 'notifikasi', 'presensi', 'jadwal', 'siswa', 'kelas', 'orang_tua', 'guru'] as $tbl) {
            Schema::dropIfExists($tbl);
        }
    }
};
