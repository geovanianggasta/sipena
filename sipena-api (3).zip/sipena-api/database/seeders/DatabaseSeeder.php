<?php

namespace Database\Seeders;

use App\Models\Guru;
use App\Models\Kelas;
use App\Models\OrangTua;
use App\Models\Siswa;
use App\Models\User;
use Illuminate\Database\Seeder;

/** Data demo. Semua password: "password" -- WAJIB diganti di produksi. */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $akun = fn($u, $n, $r) => User::create(['name' => $n, 'username' => $u, 'password' => 'password', 'role' => $r]);

        $akun('admin', 'Admin IT Sekolah', 'admin');
        $akun('kepsek', 'Kepala Sekolah', 'kepala_sekolah');
        $uGuru = $akun('guru1', 'Pak Budi', 'guru');
        $uWali = $akun('wali6a', 'Bu Lina', 'wali_kelas');
        $uOrtu = $akun('ortu1', 'Bapak Hartono', 'orang_tua');

        $budi = Guru::create(['nip' => '198001012005011001', 'nama' => 'Pak Budi', 'mata_pelajaran' => 'Matematika', 'kontak' => '081200000001', 'user_id' => $uGuru->id]);
        $lina = Guru::create(['nip' => '198502022010012002', 'nama' => 'Bu Lina', 'mata_pelajaran' => 'Bahasa Indonesia', 'kontak' => '081200000002', 'user_id' => $uWali->id]);

        $k6a = Kelas::create(['nama_kelas' => '6A', 'tingkat' => 6, 'wali_kelas_id' => $lina->id, 'tahun_ajaran' => '2026/2027']);
        $k4c = Kelas::create(['nama_kelas' => '4C', 'tingkat' => 4, 'wali_kelas_id' => null, 'tahun_ajaran' => '2026/2027']);

        $ortu = OrangTua::create(['nama' => 'Bapak Hartono', 'hubungan' => 'ayah', 'no_hp' => '081234567890', 'alamat' => 'Madiun', 'user_id' => $uOrtu->id]);

        Siswa::create(['nisn' => '0012345001', 'nama' => 'Willy Hartono', 'kelas_id' => $k6a->id, 'ortu_id' => $ortu->id]);
        Siswa::create(['nisn' => '0012345002', 'nama' => 'Riella Wijaya', 'kelas_id' => $k6a->id, 'ortu_id' => $ortu->id]);
        Siswa::create(['nisn' => '0012345003', 'nama' => 'Bekti Wibawa', 'kelas_id' => $k6a->id]);
        Siswa::create(['nisn' => '0012345004', 'nama' => 'Cahya Prasetyo', 'kelas_id' => $k6a->id]);
        Siswa::create(['nisn' => '0012345005', 'nama' => 'Amanda Prilly', 'kelas_id' => $k4c->id]);
    }
}
