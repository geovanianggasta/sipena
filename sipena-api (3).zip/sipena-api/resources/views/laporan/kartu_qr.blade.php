<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:11px}
table.grid{width:100%;border-collapse:separate;border-spacing:8px}
td.card{width:50%;border:1px solid #333;padding:8px;text-align:center}
.n{font-size:13px;font-weight:bold}
</style></head><body>
<table class="grid">
@foreach($kartu->chunk(2) as $baris)
<tr>
@foreach($baris as $k)
<td class="card"><div>SDN 03 Manisrejo - Kartu Presensi</div>
<img src="data:image/svg+xml;base64,{{ $k['svg'] }}" width="130" height="130">
<div class="n">{{ $k['nama'] }}</div><div>Kelas {{ $k['kelas'] }} | NISN {{ $k['nisn'] }}</div></td>
@endforeach
@if($baris->count() === 1)<td></td>@endif
</tr>
@endforeach
</table></body></html>
