<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:11px}
h2{margin:0 0 4px} table{width:100%;border-collapse:collapse;margin-top:10px}
th,td{border:1px solid #444;padding:4px 6px} th{background:#e5e9f5} td.n{text-align:center}
</style></head><body>
<h2>Rekap Kehadiran Siswa - SDN 03 Manisrejo</h2>
<div>Periode: {{ $dari }} s.d. {{ $sampai }}</div>
<table>
<tr><th>No</th><th>NISN</th><th>Nama</th><th>Kelas</th><th>H</th><th>I</th><th>S</th><th>A</th><th>% Hadir</th></tr>
@foreach($rekap as $i => $r)
<tr><td class="n">{{ $i+1 }}</td><td>{{ $r['nisn'] }}</td><td>{{ $r['nama'] }}</td><td>{{ $r['kelas'] }}</td>
<td class="n">{{ $r['hadir'] }}</td><td class="n">{{ $r['izin'] }}</td><td class="n">{{ $r['sakit'] }}</td><td class="n">{{ $r['alpha'] }}</td><td class="n">{{ $r['persentase_hadir'] }}%</td></tr>
@endforeach
</table></body></html>
