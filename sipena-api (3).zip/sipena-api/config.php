<?php
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'sipena');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('CORS_ORIGIN', getenv('CORS_ORIGIN') ?: '*');
define('SESSION_HOURS', 12);
date_default_timezone_set('Asia/Jakarta');
