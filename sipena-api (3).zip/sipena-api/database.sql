CREATE DATABASE IF NOT EXISTS sipena CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sipena;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nama VARCHAR(100) NOT NULL,
  role ENUM('admin','kepala_sekolah','wali_kelas','guru','orang_tua') NOT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1
);

CREATE TABLE sesi (
  token_hash CHAR(64) PRIMARY KEY,
  user_id INT NOT NULL,
  kedaluwarsa DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE guru (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL UNIQUE,
  nip VARCHAR(30) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  mata_pelajaran VARCHAR(100) NULL,
  kontak VARCHAR(20) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE orang_tua (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  hubungan VARCHAR(30) NOT NULL,
  no_hp VARCHAR(20) NOT NULL,
  alamat TEXT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE kelas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_kelas VARCHAR(20) NOT NULL UNIQUE,
  tingkat TINYINT NOT NULL,
  wali_kelas_id INT NULL,
  tahun_ajaran VARCHAR(9) NOT NULL,
  FOREIGN KEY (wali_kelas_id) REFERENCES guru(id) ON DELETE RESTRICT
);

CREATE TABLE siswa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nisn VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  kelas_id INT NOT NULL,
  ortu_id INT NULL,
  qr_code VARCHAR(40) NOT NULL UNIQUE,
  FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE RESTRICT,
  FOREIGN KEY (ortu_id) REFERENCES orang_tua(id) ON DELETE RESTRICT
);

CREATE TABLE jadwal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kelas_id INT NOT NULL,
  guru_id INT NOT NULL,
  mata_pelajaran VARCHAR(100) NOT NULL,
  hari ENUM('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu') NOT NULL,
  jam_mulai TIME NOT NULL,
  jam_selesai TIME NOT NULL,
  FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE RESTRICT,
  FOREIGN KEY (guru_id) REFERENCES guru(id) ON DELETE RESTRICT
);

CREATE TABLE presensi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  siswa_id INT NOT NULL,
  tanggal DATE NOT NULL,
  waktu_scan TIME NULL,
  status ENUM('hadir','sakit','izin','alpha') NOT NULL,
  keterangan VARCHAR(255) NULL,
  status_validasi TINYINT(1) NOT NULL DEFAULT 0,
  divalidasi_oleh INT NULL,
  divalidasi_pada DATETIME NULL,
  UNIQUE KEY uq_siswa_tanggal (siswa_id, tanggal),
  INDEX idx_tanggal (tanggal),
  FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE RESTRICT,
  FOREIGN KEY (divalidasi_oleh) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE notifikasi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ortu_id INT NOT NULL,
  presensi_id INT NOT NULL,
  pesan VARCHAR(255) NOT NULL,
  tanggal DATETIME NOT NULL,
  status_kirim ENUM('terkirim','gagal') NOT NULL,
  FOREIGN KEY (ortu_id) REFERENCES orang_tua(id) ON DELETE CASCADE,
  FOREIGN KEY (presensi_id) REFERENCES presensi(id) ON DELETE CASCADE
);

CREATE TABLE log_perubahan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  presensi_id INT NOT NULL,
  pengguna VARCHAR(100) NOT NULL,
  waktu DATETIME NOT NULL,
  status_lama ENUM('hadir','sakit','izin','alpha') NOT NULL,
  status_baru ENUM('hadir','sakit','izin','alpha') NOT NULL,
  alasan VARCHAR(255) NOT NULL,
  FOREIGN KEY (presensi_id) REFERENCES presensi(id) ON DELETE CASCADE
);
