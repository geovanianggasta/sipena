<?php

namespace Tests\Feature;

use App\Models\Presensi;
use App\Models\Siswa;
use App\Models\User;
use Database\Seeders\DatabaseSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class SipenaTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DatabaseSeeder::class);
    }

    private function as(string $username): static
    {
        app('auth')->forgetGuards();
        Sanctum::actingAs(User::where('username', $username)->firstOrFail());
        return $this;
    }

    private function qr(string $nama): string
    {
        return Siswa::where('nama', $nama)->firstOrFail()->qr_code;
    }

    public function test_login_logout(): void
    {
        $this->postJson('/api/login', ['username' => 'guru1', 'password' => 'salah'])->assertStatus(401);
        $this->postJson('/api/login', ['username' => 'guru1', 'password' => 'password'])
            ->assertOk()->assertJsonStructure(['token', 'user']);
        $this->getJson('/api/me')->assertStatus(401);
    }

    public function test_hak_akses_per_peran(): void
    {
        $this->as('guru1')->getJson('/api/users')->assertStatus(403);
        $this->as('guru1')->postJson('/api/validasi', ['tanggal' => now()->toDateString()])->assertStatus(403);
        $this->as('ortu1')->postJson('/api/presensi/scan', ['qr_code' => 'x'])->assertStatus(403);
        $this->as('admin')->getJson('/api/users')->assertOk();
    }

    public function test_alur_presensi_validasi_koreksi_notifikasi(): void
    {
        // scan valid, scan ulang, QR palsu
        $this->as('guru1')->postJson('/api/presensi/scan', ['qr_code' => $this->qr('Willy Hartono')])->assertStatus(201);
        $this->postJson('/api/presensi/scan', ['qr_code' => $this->qr('Willy Hartono')])->assertOk()->assertJson(['hasil' => 'sudah_ada']);
        $this->postJson('/api/presensi/scan', ['qr_code' => 'palsu'])->assertStatus(404);

        // manual
        $riella = Siswa::where('nama', 'Riella Wijaya')->first();
        $this->postJson('/api/presensi/manual', ['siswa_id' => $riella->id, 'status' => 'alpha'])->assertStatus(201);
        $this->postJson('/api/presensi/manual', ['siswa_id' => $riella->id, 'status' => 'kabur'])->assertStatus(422);

        // daftar absensi
        $this->getJson('/api/presensi')->assertOk()->assertJsonCount(5, 'data');

        // rekap + dashboard
        $this->getJson('/api/rekap')->assertOk();
        $this->getJson('/api/dashboard')->assertOk()->assertJsonPath('statistik.hadir', 1);

        // validasi oleh wali kelas
        $this->as('wali6a')->getJson('/api/validasi')->assertOk()->assertJsonPath('belum_divalidasi', 2);
        $this->postJson('/api/validasi', ['tanggal' => now()->toDateString()])->assertOk()->assertJsonPath('jumlah', 2);
        $this->postJson('/api/validasi', ['tanggal' => now()->toDateString()])->assertStatus(422);

        // setelah validasi, input manual guru ditolak, koreksi wali kelas jalan
        $this->as('guru1')->postJson('/api/presensi/manual', ['siswa_id' => $riella->id, 'status' => 'izin'])->assertStatus(422);
        $p = Presensi::where('siswa_id', $riella->id)->first();
        $this->as('wali6a')->patchJson("/api/presensi/{$p->id}/koreksi", ['status' => 'izin', 'alasan' => 'Ada surat izin'])->assertOk();
        $this->assertDatabaseHas('log_perubahan', ['presensi_id' => $p->id, 'status_lama' => 'alpha', 'status_baru' => 'izin']);
        $this->patchJson("/api/presensi/{$p->id}/koreksi", ['status' => 'izin', 'alasan' => 'lagi'])->assertStatus(422);

        // orang tua: dashboard, rekap, notifikasi (2 presensi + 1 koreksi)
        $this->as('ortu1')->getJson('/api/ortu/anak')->assertOk()->assertJsonCount(2, 'data');
        $this->getJson("/api/ortu/anak/{$riella->id}/rekap")->assertOk()->assertJsonPath('ringkasan.izin', 1);
        $this->getJson('/api/ortu/notifikasi')->assertOk()->assertJsonPath('total', 3);
        $other = Siswa::where('nama', 'Amanda Prilly')->first();
        $this->getJson("/api/ortu/anak/{$other->id}/rekap")->assertStatus(403);
    }

    public function test_notifikasi_gagal_jika_tanpa_kontak_ortu(): void
    {
        $this->as('guru1')->postJson('/api/presensi/scan', ['qr_code' => $this->qr('Bekti Wibawa')])->assertStatus(201);
        $this->assertDatabaseHas('notifikasi', ['status_kirim' => 'gagal']);
    }

    public function test_kepala_sekolah_dan_ekspor(): void
    {
        $this->as('guru1')->postJson('/api/presensi/scan', ['qr_code' => $this->qr('Willy Hartono')]);
        $this->as('kepsek')->getJson('/api/dashboard')->assertOk()->assertJsonStructure(['persentase_per_kelas', 'alpha_berulang', 'tren_bulanan']);
        $this->get('/api/rekap/ekspor?format=xlsx')->assertOk();
        $this->get('/api/rekap/ekspor?format=pdf')->assertOk();
    }

    public function test_crud_master_dan_penjaga_hapus(): void
    {
        $this->as('admin');
        $kelas = \App\Models\Kelas::where('nama_kelas', '6A')->first();

        $this->postJson('/api/siswa', ['nisn' => '0012345001', 'nama' => 'Dobel', 'kelas_id' => $kelas->id])->assertStatus(422);
        $id = $this->postJson('/api/siswa', ['nisn' => '0099999999', 'nama' => 'Siswa Baru', 'kelas_id' => $kelas->id])->assertStatus(201)->json('id');
        $this->putJson("/api/siswa/$id", ['nisn' => '0099999999', 'nama' => 'Siswa Baru 2', 'kelas_id' => $kelas->id])->assertOk();
        $this->deleteJson("/api/siswa/$id")->assertOk();

        $this->deleteJson("/api/kelas/{$kelas->id}")->assertStatus(409); // masih ada siswa

        // jadwal bentrok
        $guru = \App\Models\Guru::first();
        $j = ['kelas_id' => $kelas->id, 'guru_id' => $guru->id, 'mata_pelajaran' => 'IPA', 'hari' => 'Senin', 'jam_mulai' => '07:00', 'jam_selesai' => '08:00'];
        $this->postJson('/api/jadwal', $j)->assertStatus(201);
        $this->postJson('/api/jadwal', array_merge($j, ['jam_mulai' => '07:30', 'jam_selesai' => '08:30']))->assertStatus(422);

        // akun
        $uid = $this->postJson('/api/users', ['name' => 'Guru Baru', 'username' => 'guru2', 'password' => 'rahasia1', 'role' => 'guru'])->assertStatus(201)->json('id');
        $this->postJson('/api/users', ['name' => 'X', 'username' => 'guru2', 'password' => 'rahasia1', 'role' => 'guru'])->assertStatus(422);
        $this->deleteJson("/api/users/$uid")->assertOk();

        // siswa yang punya presensi tidak bisa dihapus
        $this->as('guru1')->postJson('/api/presensi/scan', ['qr_code' => $this->qr('Willy Hartono')]);
        $w = Siswa::where('nama', 'Willy Hartono')->first();
        $this->as('admin')->deleteJson("/api/siswa/{$w->id}")->assertStatus(409);
    }

    public function test_impor_siswa_dan_kartu_qr(): void
    {
        $this->as('admin');
        $csv = "nisn,nama,kelas\n0077000001,Anak Satu,6A\n0077000002,Anak Dua,9Z\n0012345001,Dobel,6A\n";
        $f = fn() => UploadedFile::fake()->createWithContent('siswa.csv', $csv);

        $this->postJson('/api/siswa/impor/pratinjau', ['file' => $f()])->assertOk()->assertJsonPath('valid', 1)->assertJsonPath('total', 3);
        $this->assertDatabaseMissing('siswa', ['nisn' => '0077000001']);
        $this->postJson('/api/siswa/impor', ['file' => $f()])->assertOk()->assertJsonPath('berhasil', 1)->assertJsonPath('gagal', 2);
        $this->assertDatabaseHas('siswa', ['nisn' => '0077000001']);

        $s = Siswa::where('nisn', '0077000001')->first();
        $this->get("/api/siswa/{$s->id}/qr")->assertOk();
        $this->get("/api/qr/kartu?siswa_id={$s->id}")->assertOk();
        $this->get('/api/siswa/template')->assertOk();
    }
}
