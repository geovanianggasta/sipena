<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
body{font-family:DejaVu Sans,sans-serif;font-size:11px}
table.grid{width:100%;border-collapse:separate;border-spacing:8px}
td.card{width:50%;border:1px solid #333;padding:8px;text-align:center}
.n{font-size:13px;font-weight:bold}
</style></head><body>
<table class="grid">
<?php $__currentLoopData = $kartu->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<?php $__currentLoopData = $baris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td class="card"><div>SDN 03 Manisrejo - Kartu Presensi</div>
<img src="data:image/svg+xml;base64,<?php echo e($k['svg']); ?>" width="130" height="130">
<div class="n"><?php echo e($k['nama']); ?></div><div>Kelas <?php echo e($k['kelas']); ?> | NISN <?php echo e($k['nisn']); ?></div></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($baris->count() === 1): ?><td></td><?php endif; ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table></body></html>
<?php /**PATH C:\Users\ACER\Desktop\sipena-api\resources\views/laporan/kartu_qr.blade.php ENDPATH**/ ?>