<?php
const HARI = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const ROLES = ['admin', 'kepala_sekolah', 'wali_kelas', 'guru', 'orang_tua'];
const BACA_UMUM = ['admin', 'guru', 'wali_kelas', 'kepala_sekolah'];

function kodeQR(): string
{
    return 'SIPENA-' . strtoupper(bin2hex(random_bytes(8)));
}

$MASTER = [
    'siswa' => [
        'table' => 'siswa',
        'select' => 'SELECT t.*, k.nama_kelas, o.nama AS nama_ortu FROM siswa t
                     JOIN kelas k ON k.id = t.kelas_id LEFT JOIN orang_tua o ON o.id = t.ortu_id',
        'fields' => ['nisn', 'nama', 'kelas_id', 'ortu_id'],
        'required' => ['nisn', 'nama', 'kelas_id'],
        'unique' => ['nisn' => 'NISN sudah terdaftar'],
        'search' => ['t.nama', 't.nisn'],
        'filters' => ['kelas_id'],
        'read' => BACA_UMUM,
        'on_create' => fn() => ['qr_code' => kodeQR()],
    ],
    'guru' => [
        'table' => 'guru',
        'select' => 'SELECT t.* FROM guru t',
        'fields' => ['nip', 'nama', 'mata_pelajaran', 'kontak', 'user_id'],
        'required' => ['nip', 'nama'],
        'unique' => ['nip' => 'NIP/ID guru sudah terdaftar'],
        'search' => ['t.nama', 't.nip'],
    ],
    'kelas' => [
        'table' => 'kelas',
        'select' => 'SELECT t.*, g.nama AS nama_wali FROM kelas t LEFT JOIN guru g ON g.id = t.wali_kelas_id',
        'fields' => ['nama_kelas', 'tingkat', 'wali_kelas_id', 'tahun_ajaran'],
        'required' => ['nama_kelas', 'tingkat', 'tahun_ajaran'],
        'unique' => ['nama_kelas' => 'Nama kelas sudah ada'],
        'search' => ['t.nama_kelas'],
        'read' => BACA_UMUM,
    ],
    'orangtua' => [
        'table' => 'orang_tua',
        'select' => 'SELECT t.* FROM orang_tua t',
        'fields' => ['nama', 'hubungan', 'no_hp', 'alamat', 'user_id'],
        'required' => ['nama', 'hubungan', 'no_hp'],
        'search' => ['t.nama', 't.no_hp'],
        'validate' => fn($d) => preg_match('/^\+?[0-9]{8,15}$/', preg_replace('/[\s-]/', '', (string)$d['no_hp']))
            ? [] : ['no_hp' => 'Format nomor kontak tidak valid'],
    ],
    'jadwal' => [
        'table' => 'jadwal',
        'select' => 'SELECT t.*, k.nama_kelas, g.nama AS nama_guru FROM jadwal t
                     JOIN kelas k ON k.id = t.kelas_id JOIN guru g ON g.id = t.guru_id',
        'fields' => ['kelas_id', 'guru_id', 'mata_pelajaran', 'hari', 'jam_mulai', 'jam_selesai'],
        'required' => ['kelas_id', 'guru_id', 'mata_pelajaran', 'hari', 'jam_mulai', 'jam_selesai'],
        'search' => ['t.mata_pelajaran'],
        'filters' => ['kelas_id', 'guru_id'],
        'validate' => function ($d, $id) {
            $err = [];
            if (!in_array($d['hari'], HARI, true)) $err['hari'] = 'Hari tidak valid';
            if (strtotime($d['jam_mulai']) === false || strtotime($d['jam_selesai']) === false) {
                $err['jam_mulai'] = 'Format jam tidak valid';
            } elseif (strtotime($d['jam_mulai']) >= strtotime($d['jam_selesai'])) {
                $err['jam_selesai'] = 'Jam selesai harus setelah jam mulai';
            }
            if (!$err && q('SELECT 1 FROM jadwal WHERE hari = ? AND id <> ? AND jam_mulai < ? AND jam_selesai > ? AND (kelas_id = ? OR guru_id = ?)',
                [$d['hari'], $id ?? 0, $d['jam_selesai'], $d['jam_mulai'], $d['kelas_id'], $d['guru_id']])->fetch()) {
                $err['jam_mulai'] = 'Jadwal bentrok dengan jadwal kelas atau guru lain';
            }
            return $err;
        },
    ],
    'akun' => [
        'table' => 'users',
        'select' => 'SELECT t.id, t.username, t.nama, t.role, t.aktif FROM users t',
        'fields' => ['username', 'nama', 'role', 'aktif'],
        'required' => ['username', 'nama', 'role'],
        'unique' => ['username' => 'Username sudah dipakai'],
        'search' => ['t.username', 't.nama'],
        'filters' => ['role'],
        'custom_write' => true,
        'validate' => fn($d) => in_array($d['role'], ROLES, true) ? [] : ['role' => 'Role tidak valid'],
        'guard' => function ($id, $u) {
            if ($id === (int)$u['id']) fail('Tidak dapat menghapus akun sendiri', 409);
        },
    ],
];

function dbInsert(string $table, array $d): int
{
    $cols = array_keys($d);
    q("INSERT INTO $table (" . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($d));
    return (int)db()->lastInsertId();
}

function dbUpdate(string $table, int $id, array $d): void
{
    q("UPDATE $table SET " . implode(',', array_map(fn($c) => "$c = ?", array_keys($d))) . ' WHERE id = ?', [...array_values($d), $id]);
}

function masterFind(array $c, int $id): array
{
    $r = q($c['select'] . ' WHERE t.id = ?', [$id])->fetch();
    if (!$r) fail('Data tidak ditemukan', 404);
    return $r;
}

function masterSave(array $c, ?int $id): array
{
    $base = [];
    if ($id !== null) {
        $cur = q("SELECT * FROM {$c['table']} WHERE id = ?", [$id])->fetch();
        if (!$cur) fail('Data tidak ditemukan', 404);
        $base = array_intersect_key($cur, array_flip($c['fields']));
    }
    $in = array_intersect_key(input(), array_flip($c['fields']));
    $d = array_merge($base, $in);
    foreach ($d as $k => $v) {
        if (is_string($v)) $v = trim($v);
        $d[$k] = is_bool($v) ? (int)$v : ($v === '' ? null : $v);
    }
    $err = [];
    foreach ($c['required'] as $f) {
        if (($d[$f] ?? null) === null) $err[$f] = 'Wajib diisi';
    }
    foreach ($c['unique'] ?? [] as $f => $msg) {
        if (!isset($err[$f]) && q("SELECT 1 FROM {$c['table']} WHERE $f = ? AND id <> ?", [$d[$f], $id ?? 0])->fetch()) {
            $err[$f] = $msg;
        }
    }
    if (!$err && isset($c['validate'])) $err = $c['validate']($d, $id);
    if ($err) fail('Data tidak valid', 422, $err);
    return $d;
}

function masterList(array $c): void
{
    $w = [];
    $a = [];
    if (($kw = trim((string)($_GET['q'] ?? ''))) !== '') {
        $w[] = '(' . implode(' OR ', array_map(fn($f) => "$f LIKE ?", $c['search'])) . ')';
        foreach ($c['search'] as $_) $a[] = "%$kw%";
    }
    foreach ($c['filters'] ?? [] as $f) {
        if (isset($_GET[$f]) && $_GET[$f] !== '') {
            $w[] = "t.$f = ?";
            $a[] = $_GET[$f];
        }
    }
    $where = $w ? ' WHERE ' . implode(' AND ', $w) : '';
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per = min(100, max(1, (int)($_GET['per_page'] ?? 20)));
    $total = (int)q("SELECT COUNT(*) FROM {$c['table']} t $where", $a)->fetchColumn();
    $items = q($c['select'] . $where . ' ORDER BY t.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $a)->fetchAll();
    ok(['items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $per]);
}

function masterCreate(array $c): void
{
    $d = masterSave($c, null);
    if (isset($c['on_create'])) $d += $c['on_create']();
    ok(masterFind($c, dbInsert($c['table'], $d)), 'Data berhasil ditambahkan', 201);
}

function masterEdit(array $c, int $id): void
{
    dbUpdate($c['table'], $id, masterSave($c, $id));
    ok(masterFind($c, $id), 'Data berhasil diperbarui');
}

function masterDelete(array $c, int $id, array $u): void
{
    if (isset($c['guard'])) $c['guard']($id, $u);
    if (!q("DELETE FROM {$c['table']} WHERE id = ?", [$id])->rowCount()) fail('Data tidak ditemukan', 404);
    ok(null, 'Data berhasil dihapus');
}

foreach ($MASTER as $name => $c) {
    $read = $c['read'] ?? ['admin'];
    route('GET', $name, $read, fn() => masterList($c));
    route('GET', "$name/{id}", $read, fn($p) => ok(masterFind($c, (int)$p['id'])));
    route('DELETE', "$name/{id}", ['admin'], fn($p, $u) => masterDelete($c, (int)$p['id'], $u));
    if (empty($c['custom_write'])) {
        route('POST', $name, ['admin'], fn() => masterCreate($c));
        route('PUT', "$name/{id}", ['admin'], fn($p) => masterEdit($c, (int)$p['id']));
    }
}

$akun = $MASTER['akun'];

route('POST', 'akun', ['admin'], function () use ($akun) {
    $pw = (string)(input()['password'] ?? '');
    $d = masterSave($akun, null);
    if (strlen($pw) < 6) fail('Data tidak valid', 422, ['password' => 'Minimal 6 karakter']);
    $d['password'] = password_hash($pw, PASSWORD_DEFAULT);
    ok(masterFind($akun, dbInsert('users', $d)), 'Akun berhasil ditambahkan', 201);
});

route('PUT', 'akun/{id}', ['admin'], function ($p) use ($akun) {
    $id = (int)$p['id'];
    $d = masterSave($akun, $id);
    $pw = (string)(input()['password'] ?? '');
    if ($pw !== '') {
        if (strlen($pw) < 6) fail('Data tidak valid', 422, ['password' => 'Minimal 6 karakter']);
        $d['password'] = password_hash($pw, PASSWORD_DEFAULT);
    }
    dbUpdate('users', $id, $d);
    ok(masterFind($akun, $id), 'Akun berhasil diperbarui');
});

route('GET', 'kartu-qr', ['admin'], function () {
    $kelas = (int)($_GET['kelas_id'] ?? 0);
    $siswa = (int)($_GET['siswa_id'] ?? 0);
    if (!$kelas && !$siswa) fail('kelas_id atau siswa_id wajib', 422);
    $sql = 'SELECT s.id, s.nisn, s.nama, k.nama_kelas, s.qr_code FROM siswa s JOIN kelas k ON k.id = s.kelas_id WHERE ' . ($siswa ? 's.id = ?' : 's.kelas_id = ?');
    $rows = q($sql . ' ORDER BY s.nama', [$siswa ?: $kelas])->fetchAll();
    if (!$rows) fail('Siswa tidak ditemukan', 404);
    ok($rows);
});

route('GET', 'siswa/import/template', ['admin'], function () {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="template-siswa.csv"');
    echo "\xEF\xBB\xBFnisn,nama,nama_kelas\n0012345678,Contoh Siswa,1A\n";
    exit;
});

route('POST', 'siswa/import', ['admin'], function () {
    if (empty($_FILES['file']['tmp_name'])) fail('File belum diunggah', 422);
    $simpan = ($_POST['mode'] ?? 'preview') === 'simpan';
    $fh = fopen($_FILES['file']['tmp_name'], 'r');
    $first = (string)fgets($fh);
    rewind($fh);
    $sep = substr_count($first, ';') > substr_count($first, ',') ? ';' : ',';
    $head = fgetcsv($fh, 0, $sep, '"', '\\');
    if (!$head) fail('File kosong', 422);
    $head[0] = ltrim($head[0], "\xEF\xBB\xBF");
    $head = array_map(fn($h) => strtolower(trim($h)), $head);
    if (array_diff(['nisn', 'nama', 'nama_kelas'], $head)) fail('Format kolom tidak sesuai template', 422);

    $kelas = array_column(q('SELECT id, nama_kelas FROM kelas')->fetchAll(), 'id', 'nama_kelas');
    $rows = [];
    $seen = [];
    $baris = 1;
    while (($r = fgetcsv($fh, 0, $sep, '"', '\\')) !== false) {
        $baris++;
        if ($r === [null]) continue;
        $r = array_map('trim', array_slice(array_pad($r, count($head), ''), 0, count($head)));
        $row = array_combine($head, $r);
        $err = null;
        if ($row['nisn'] === '' || $row['nama'] === '') {
            $err = 'NISN dan nama wajib diisi';
        } elseif (!isset($kelas[$row['nama_kelas']])) {
            $err = 'Kelas tidak ditemukan';
        } elseif (isset($seen[$row['nisn']]) || q('SELECT 1 FROM siswa WHERE nisn = ?', [$row['nisn']])->fetch()) {
            $err = 'NISN duplikat';
        }
        $seen[$row['nisn']] = true;
        $rows[] = ['baris' => $baris, 'nisn' => $row['nisn'], 'nama' => $row['nama'], 'nama_kelas' => $row['nama_kelas'], 'error' => $err];
    }
    fclose($fh);

    $valid = array_filter($rows, fn($r) => !$r['error']);
    if ($simpan) {
        db()->beginTransaction();
        foreach ($valid as $r) {
            dbInsert('siswa', ['nisn' => $r['nisn'], 'nama' => $r['nama'], 'kelas_id' => $kelas[$r['nama_kelas']], 'qr_code' => kodeQR()]);
        }
        db()->commit();
    }
    ok([
        'mode' => $simpan ? 'simpan' : 'preview',
        'berhasil' => count($valid),
        'gagal' => count($rows) - count($valid),
        'rows' => $rows,
    ], $simpan ? 'Impor selesai' : 'Pratinjau impor');
});
