<?php
const STATUS = ['hadir', 'sakit', 'izin', 'alpha'];
const PETUGAS = ['guru', 'wali_kelas'];

function notifOrtu(int $presensiId, int $siswaId, string $status): void
{
    $r = q('SELECT s.nama, o.id AS oid, o.no_hp FROM siswa s LEFT JOIN orang_tua o ON o.id = s.ortu_id WHERE s.id = ?', [$siswaId])->fetch();
    if (!$r || !$r['oid']) return;
    q('INSERT INTO notifikasi (ortu_id, presensi_id, pesan, tanggal, status_kirim) VALUES (?,?,?,?,?)', [
        $r['oid'], $presensiId,
        "{$r['nama']} tercatat {$status} pada " . date('d-m-Y H:i'),
        date('Y-m-d H:i:s'),
        $r['no_hp'] ? 'terkirim' : 'gagal',
    ]);
}

function catatPresensi(int $siswaId, string $status, ?string $ket, string $tgl): array
{
    $ada = q('SELECT id, status_validasi FROM presensi WHERE siswa_id = ? AND tanggal = ?', [$siswaId, $tgl])->fetch();
    if ($ada && $ada['status_validasi']) {
        fail('Data sudah divalidasi wali kelas, gunakan koreksi', 409);
    }
    if ($ada) {
        $id = (int)$ada['id'];
        q('UPDATE presensi SET status = ?, keterangan = ?, waktu_scan = ? WHERE id = ?', [$status, $ket, date('H:i:s'), $id]);
    } else {
        q('INSERT INTO presensi (siswa_id, tanggal, waktu_scan, status, keterangan) VALUES (?,?,?,?,?)',
            [$siswaId, $tgl, date('H:i:s'), $status, $ket]);
        $id = (int)db()->lastInsertId();
    }
    notifOrtu($id, $siswaId, $status);
    return q('SELECT * FROM presensi WHERE id = ?', [$id])->fetch();
}

route('POST', 'presensi/scan', PETUGAS, function () {
    $kode = trim((string)(input()['qr_code'] ?? ''));
    $s = $kode === '' ? false : q('SELECT s.id, s.nisn, s.nama, k.nama_kelas FROM siswa s JOIN kelas k ON k.id = s.kelas_id WHERE s.qr_code = ?', [$kode])->fetch();
    if (!$s) fail('QR tidak valid atau tidak terdaftar', 404);
    $tgl = date('Y-m-d');
    if (q('SELECT 1 FROM presensi WHERE siswa_id = ? AND tanggal = ?', [$s['id'], $tgl])->fetch()) {
        fail("{$s['nama']} sudah tercatat hari ini", 409, $s);
    }
    ok(['siswa' => $s, 'presensi' => catatPresensi((int)$s['id'], 'hadir', null, $tgl)], 'Presensi berhasil dicatat', 201);
});

route('POST', 'presensi/manual', PETUGAS, function () {
    $in = input();
    $status = $in['status'] ?? '';
    if (!in_array($status, STATUS, true)) fail('Status harus hadir, sakit, izin, atau alpha', 422);
    $sid = (int)($in['siswa_id'] ?? 0);
    if (!q('SELECT 1 FROM siswa WHERE id = ?', [$sid])->fetch()) fail('Siswa tidak ditemukan', 404);
    $ket = isset($in['keterangan']) ? trim((string)$in['keterangan']) : null;
    ok(catatPresensi($sid, $status, $ket ?: null, tanggal($in['tanggal'] ?? null)), 'Presensi tersimpan', 201);
});

route('POST', 'presensi/tandai-alpha', PETUGAS, function () {
    $in = input();
    $kelas = (int)($in['kelas_id'] ?? 0);
    if (!$kelas) fail('kelas_id wajib', 422);
    $tgl = tanggal($in['tanggal'] ?? null);
    $ids = q('SELECT id FROM siswa WHERE kelas_id = ? AND id NOT IN (SELECT siswa_id FROM presensi WHERE tanggal = ?)', [$kelas, $tgl])->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $id) catatPresensi((int)$id, 'alpha', null, $tgl);
    ok(['jumlah' => count($ids)], count($ids) . ' siswa ditandai alpha');
});

route('GET', 'presensi', ['guru', 'wali_kelas', 'kepala_sekolah'], function () {
    $kelas = (int)($_GET['kelas_id'] ?? 0);
    if (!$kelas) fail('kelas_id wajib', 422);
    $tgl = tanggal($_GET['tanggal'] ?? null);
    $sql = 'SELECT s.id AS siswa_id, s.nisn, s.nama, p.id AS presensi_id, p.status, p.waktu_scan, p.keterangan, p.status_validasi
            FROM siswa s LEFT JOIN presensi p ON p.siswa_id = s.id AND p.tanggal = ? WHERE s.kelas_id = ?';
    $a = [$tgl, $kelas];
    if (($kw = trim((string)($_GET['q'] ?? ''))) !== '') {
        $sql .= ' AND s.nama LIKE ?';
        $a[] = "%$kw%";
    }
    $items = q($sql . ' ORDER BY s.nama', $a)->fetchAll();
    $ringkas = array_fill_keys(STATUS, 0);
    $belum = 0;
    foreach ($items as $i) {
        if ($i['status']) $ringkas[$i['status']]++;
        if ($i['presensi_id'] && !$i['status_validasi']) $belum++;
    }
    ok(['tanggal' => $tgl, 'ringkasan' => $ringkas, 'belum_validasi' => $belum, 'items' => $items]);
});

route('PUT', 'presensi/{id}/koreksi', ['wali_kelas'], function ($p, $u) {
    $in = input();
    $status = $in['status'] ?? '';
    $alasan = trim((string)($in['alasan'] ?? ''));
    $err = [];
    if (!in_array($status, STATUS, true)) $err['status'] = 'Status tidak valid';
    if ($alasan === '') $err['alasan'] = 'Alasan koreksi wajib diisi';
    if ($err) fail('Data tidak valid', 422, $err);

    $pr = q('SELECT p.*, s.kelas_id FROM presensi p JOIN siswa s ON s.id = p.siswa_id WHERE p.id = ?', [$p['id']])->fetch();
    if (!$pr) fail('Data presensi tidak ditemukan', 404);
    if ((int)$pr['kelas_id'] !== kelasWali($u)) fail('Presensi ini bukan dari kelas Anda', 403);
    if ($pr['status'] === $status) fail('Status baru sama dengan status lama', 422);

    db()->beginTransaction();
    q('UPDATE presensi SET status = ?, keterangan = ?, status_validasi = 0, divalidasi_oleh = NULL, divalidasi_pada = NULL WHERE id = ?',
        [$status, $alasan, $pr['id']]);
    q('INSERT INTO log_perubahan (presensi_id, pengguna, waktu, status_lama, status_baru, alasan) VALUES (?,?,?,?,?,?)',
        [$pr['id'], $u['nama'], date('Y-m-d H:i:s'), $pr['status'], $status, $alasan]);
    db()->commit();
    notifOrtu((int)$pr['id'], (int)$pr['siswa_id'], $status);
    ok(q('SELECT * FROM presensi WHERE id = ?', [$pr['id']])->fetch(), 'Koreksi berhasil disimpan');
});

route('GET', 'presensi/{id}/log', ['wali_kelas', 'kepala_sekolah', 'admin'], function ($p) {
    ok(q('SELECT * FROM log_perubahan WHERE presensi_id = ? ORDER BY id DESC', [$p['id']])->fetchAll());
});

route('POST', 'presensi/validasi', ['wali_kelas'], function ($p, $u) {
    $in = input();
    $kelas = (int)($in['kelas_id'] ?? kelasWali($u));
    if ($kelas !== kelasWali($u)) fail('Bukan kelas Anda', 403);
    $tgl = tanggal($in['tanggal'] ?? null);
    $n = q('UPDATE presensi p JOIN siswa s ON s.id = p.siswa_id
            SET p.status_validasi = 1, p.divalidasi_oleh = ?, p.divalidasi_pada = ?
            WHERE s.kelas_id = ? AND p.tanggal = ? AND p.status_validasi = 0',
        [$u['id'], date('Y-m-d H:i:s'), $kelas, $tgl])->rowCount();
    if (!$n) fail('Tidak ada data absensi yang perlu divalidasi', 404);
    ok(['jumlah' => $n], 'Validasi berhasil');
});
