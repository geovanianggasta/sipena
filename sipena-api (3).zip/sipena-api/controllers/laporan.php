<?php
function periode(): array
{
    return [tanggal($_GET['dari'] ?? null, date('Y-m-01')), tanggal($_GET['sampai'] ?? null, date('Y-m-d'))];
}

function rekapData(?int $kelas, ?int $siswa, string $dari, string $sampai): array
{
    $sql = "SELECT s.id, s.nisn, s.nama, k.nama_kelas,
            SUM(p.status = 'hadir') AS hadir, SUM(p.status = 'izin') AS izin,
            SUM(p.status = 'sakit') AS sakit, SUM(p.status = 'alpha') AS alpha, COUNT(p.id) AS total
            FROM siswa s JOIN kelas k ON k.id = s.kelas_id
            LEFT JOIN presensi p ON p.siswa_id = s.id AND p.tanggal BETWEEN ? AND ?
            WHERE 1 = 1";
    $a = [$dari, $sampai];
    if ($kelas) { $sql .= ' AND s.kelas_id = ?'; $a[] = $kelas; }
    if ($siswa) { $sql .= ' AND s.id = ?'; $a[] = $siswa; }
    $rows = q($sql . ' GROUP BY s.id, s.nisn, s.nama, k.nama_kelas ORDER BY s.nama', $a)->fetchAll();
    foreach ($rows as &$r) {
        foreach (['hadir', 'izin', 'sakit', 'alpha', 'total'] as $k) $r[$k] = (int)$r[$k];
        $r['persen_hadir'] = $r['total'] ? round($r['hadir'] / $r['total'] * 100, 1) : 0;
    }
    unset($r);
    return $rows;
}

function rekapParams(): array
{
    $kelas = (int)($_GET['kelas_id'] ?? 0);
    $siswa = (int)($_GET['siswa_id'] ?? 0);
    if (!$kelas && !$siswa) fail('kelas_id atau siswa_id wajib', 422);
    [$dari, $sampai] = periode();
    return [$kelas ?: null, $siswa ?: null, $dari, $sampai];
}

route('GET', 'rekap', ['guru', 'wali_kelas', 'kepala_sekolah'], function () {
    [$kelas, $siswa, $dari, $sampai] = rekapParams();
    $rows = rekapData($kelas, $siswa, $dari, $sampai);
    ok(['dari' => $dari, 'sampai' => $sampai, 'items' => $rows], $rows ? 'Berhasil' : 'Belum ada data');
});

route('GET', 'rekap/export', ['wali_kelas', 'kepala_sekolah'], function () {
    $format = strtolower($_GET['format'] ?? 'csv');
    if ($format !== 'csv') fail('Format ' . $format . ' belum didukung (tersedia: csv)', 501);
    [$kelas, $siswa, $dari, $sampai] = rekapParams();
    $rows = rekapData($kelas, $siswa, $dari, $sampai);
    if (!$rows) fail('Belum ada data untuk diekspor', 404);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="rekap-kehadiran-' . $dari . '_' . $sampai . '.csv"');
    echo "\xEF\xBB\xBF";
    $f = fopen('php://output', 'w');
    fputcsv($f, ['NISN', 'Nama', 'Kelas', 'Hadir', 'Izin', 'Sakit', 'Alpha', 'Persentase Hadir'], ',', '"', '\\');
    foreach ($rows as $r) {
        fputcsv($f, [$r['nisn'], $r['nama'], $r['nama_kelas'], $r['hadir'], $r['izin'], $r['sakit'], $r['alpha'], $r['persen_hadir'] . '%'], ',', '"', '\\');
    }
    fclose($f);
    exit;
});

route('GET', 'dashboard/guru', ['guru', 'wali_kelas'], function ($p, $u) {
    $kelas = (int)($_GET['kelas_id'] ?? 0);
    $sql = "SELECT COALESCE(SUM(p.status = 'hadir'), 0) AS hadir, COALESCE(SUM(p.status = 'sakit'), 0) AS sakit,
            COALESCE(SUM(p.status = 'izin'), 0) AS izin, COALESCE(SUM(p.status = 'alpha'), 0) AS alpha
            FROM presensi p JOIN siswa s ON s.id = p.siswa_id WHERE p.tanggal = ?";
    $a = [date('Y-m-d')];
    if ($kelas) { $sql .= ' AND s.kelas_id = ?'; $a[] = $kelas; }
    $out = ['nama' => $u['nama'], 'tanggal' => date('Y-m-d'), 'ringkasan' => array_map('intval', q($sql, $a)->fetch())];
    if ($u['role'] === 'wali_kelas') {
        $k = kelasWali($u);
        $out['kelas_id'] = $k ?: null;
        $out['belum_validasi'] = (int)q('SELECT COUNT(*) FROM presensi p JOIN siswa s ON s.id = p.siswa_id WHERE s.kelas_id = ? AND p.status_validasi = 0', [$k])->fetchColumn();
    }
    ok($out);
});

route('GET', 'dashboard/ortu', ['orang_tua'], function ($p, $u) {
    $oid = q('SELECT id FROM orang_tua WHERE user_id = ?', [$u['id']])->fetchColumn();
    if (!$oid) fail('Akun belum terhubung dengan data orang tua', 404);
    $bulan = $_GET['bulan'] ?? null;
    if ($bulan !== null && !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $bulan)) fail('Format bulan harus YYYY-MM', 422);
    $anak = q('SELECT s.id, s.nisn, s.nama, k.nama_kelas FROM siswa s JOIN kelas k ON k.id = s.kelas_id WHERE s.ortu_id = ?', [$oid])->fetchAll();
    $out = [];
    foreach ($anak as $a) {
        $a['hari_ini'] = q('SELECT status, waktu_scan, keterangan FROM presensi WHERE siswa_id = ? AND tanggal = ?', [$a['id'], date('Y-m-d')])->fetch() ?: null;
        if ($bulan) {
            $riwayat = q('SELECT tanggal, status, waktu_scan, keterangan FROM presensi WHERE siswa_id = ? AND tanggal BETWEEN ? AND ? ORDER BY tanggal',
                [$a['id'], "$bulan-01", date('Y-m-t', strtotime("$bulan-01"))])->fetchAll();
            $a['rekap_bulanan'] = array_merge(array_fill_keys(STATUS, 0), array_count_values(array_column($riwayat, 'status')));
            $a['riwayat'] = $riwayat;
        }
        $out[] = $a;
    }
    ok($out);
});

route('GET', 'notifikasi', ['orang_tua'], function ($p, $u) {
    ok(q('SELECT n.id, n.pesan, n.tanggal, n.status_kirim FROM notifikasi n JOIN orang_tua o ON o.id = n.ortu_id
          WHERE o.user_id = ? ORDER BY n.id DESC LIMIT 50', [$u['id']])->fetchAll());
});

route('GET', 'dashboard/kepsek', ['kepala_sekolah'], function () {
    $bulan = $_GET['bulan'] ?? date('Y-m');
    if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $bulan)) fail('Format bulan harus YYYY-MM', 422);
    $dari = "$bulan-01";
    $sampai = date('Y-m-t', strtotime($dari));

    $kelas = q("SELECT k.id, k.nama_kelas, COUNT(p.id) AS total, COALESCE(SUM(p.status = 'hadir'), 0) AS hadir
                FROM kelas k LEFT JOIN siswa s ON s.kelas_id = k.id
                LEFT JOIN presensi p ON p.siswa_id = s.id AND p.tanggal BETWEEN ? AND ?
                GROUP BY k.id, k.nama_kelas ORDER BY k.nama_kelas", [$dari, $sampai])->fetchAll();
    foreach ($kelas as &$k) {
        $k['total'] = (int)$k['total'];
        $k['hadir'] = (int)$k['hadir'];
        $k['persen_hadir'] = $k['total'] ? round($k['hadir'] / $k['total'] * 100, 1) : 0;
    }
    unset($k);

    $alpha = q("SELECT s.id, s.nama, k.nama_kelas, COUNT(*) AS jumlah_alpha
                FROM presensi p JOIN siswa s ON s.id = p.siswa_id JOIN kelas k ON k.id = s.kelas_id
                WHERE p.status = 'alpha' AND p.tanggal BETWEEN ? AND ?
                GROUP BY s.id, s.nama, k.nama_kelas HAVING COUNT(*) >= 3
                ORDER BY jumlah_alpha DESC LIMIT 20", [$dari, $sampai])->fetchAll();

    $mulai = (new DateTime('first day of this month'))->modify('-5 months')->format('Y-m-d');
    $tren = q("SELECT DATE_FORMAT(tanggal, '%Y-%m') AS bulan, COUNT(*) AS total, SUM(status = 'hadir') AS hadir
               FROM presensi WHERE tanggal >= ? GROUP BY bulan ORDER BY bulan", [$mulai])->fetchAll();
    foreach ($tren as &$t) {
        $t['total'] = (int)$t['total'];
        $t['hadir'] = (int)$t['hadir'];
        $t['persen_hadir'] = $t['total'] ? round($t['hadir'] / $t['total'] * 100, 1) : 0;
    }
    unset($t);

    ok(['bulan' => $bulan, 'per_kelas' => $kelas, 'alpha_berulang' => $alpha, 'tren_bulanan' => $tren]);
});

route('GET', 'dashboard/ringkasan', ['admin', 'kepala_sekolah'], function () {
    $r = q("SELECT (SELECT COUNT(*) FROM siswa) AS siswa, (SELECT COUNT(*) FROM guru) AS guru,
            (SELECT COUNT(*) FROM kelas) AS kelas, (SELECT COUNT(*) FROM users WHERE role = 'orang_tua') AS akun_ortu")->fetch();
    ok(array_map('intval', $r));
});
