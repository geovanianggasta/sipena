<?php
function profil(array $u): array
{
    $out = ['id' => (int)$u['id'], 'username' => $u['username'], 'nama' => $u['nama'], 'role' => $u['role']];
    if (in_array($u['role'], ['guru', 'wali_kelas'], true)) {
        $out['guru_id'] = guruId($u) ?: null;
    }
    if ($u['role'] === 'wali_kelas') {
        $out['kelas_id'] = kelasWali($u) ?: null;
    }
    return $out;
}

route('POST', 'login', null, function () {
    $in = input();
    $username = trim((string)($in['username'] ?? ''));
    $password = (string)($in['password'] ?? '');
    $u = $username === '' ? false : q('SELECT * FROM users WHERE username = ? AND aktif = 1', [$username])->fetch();
    if (!$u || !password_verify($password, $u['password'])) {
        fail('Username atau password salah', 401);
    }
    $token = bin2hex(random_bytes(32));
    q('INSERT INTO sesi (token_hash, user_id, kedaluwarsa) VALUES (?,?,?)',
        [hash('sha256', $token), $u['id'], date('Y-m-d H:i:s', time() + SESSION_HOURS * 3600)]);
    q('DELETE FROM sesi WHERE kedaluwarsa < ?', [date('Y-m-d H:i:s')]);
    ok(['token' => $token, 'user' => profil($u)], 'Login berhasil');
});

route('POST', 'logout', [], function () {
    q('DELETE FROM sesi WHERE token_hash = ?', [hash('sha256', bearer())]);
    ok(null, 'Logout berhasil');
});

route('GET', 'me', [], fn($p, $u) => ok(profil($u)));
