<?php
$_GET['r'] = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
require __DIR__ . '/index.php';
