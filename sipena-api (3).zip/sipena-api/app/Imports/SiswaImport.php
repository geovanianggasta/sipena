<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

/** Dipakai lewat Excel::toCollection(); baris dibaca apa adanya, validasi di controller. */
class SiswaImport implements ToCollection, WithHeadingRow
{
    public function collection(Collection $rows) {}
}
