<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogPerubahan extends Model
{
    protected $table = 'log_perubahan';
    protected $guarded = ['id'];

    public function presensi() { return $this->belongsTo(Presensi::class); }
    public function pengguna() { return $this->belongsTo(User::class, 'pengguna_id'); }
}
