<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Presensi extends Model
{
    public const STATUS = ['hadir', 'izin', 'sakit', 'alpha'];

    protected $table = 'presensi';
    protected $guarded = ['id'];
    protected $casts = ['status_validasi' => 'boolean', 'validated_at' => 'datetime'];

    public function siswa() { return $this->belongsTo(Siswa::class); }
    public function jadwal() { return $this->belongsTo(Jadwal::class); }
    public function validator() { return $this->belongsTo(User::class, 'validated_by'); }
    public function log() { return $this->hasMany(LogPerubahan::class); }
}
