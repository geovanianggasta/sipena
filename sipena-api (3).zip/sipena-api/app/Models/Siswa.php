<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Siswa extends Model
{
    protected $table = 'siswa';
    protected $guarded = ['id'];
    protected $hidden = ['qr_code'];

    protected static function booted(): void
    {
        static::creating(function (Siswa $s) {
            if (empty($s->qr_code)) {
                $s->qr_code = self::tokenBaru();
            }
        });
    }

    public static function tokenBaru(): string
    {
        do {
            $t = Str::random(40);
        } while (self::where('qr_code', $t)->exists());
        return $t;
    }

    public function kelas() { return $this->belongsTo(Kelas::class); }
    public function ortu() { return $this->belongsTo(OrangTua::class, 'ortu_id'); }
    public function presensi() { return $this->hasMany(Presensi::class); }
}
