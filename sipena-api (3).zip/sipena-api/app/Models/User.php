<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    public const ROLES = ['guru', 'wali_kelas', 'orang_tua', 'kepala_sekolah', 'admin'];

    protected $fillable = ['name', 'username', 'email', 'password', 'role', 'fcm_token'];
    protected $hidden = ['password', 'remember_token', 'fcm_token'];

    protected function casts(): array
    {
        return ['password' => 'hashed'];
    }

    public function guru(): HasOne
    {
        return $this->hasOne(Guru::class);
    }

    public function orangTua(): HasOne
    {
        return $this->hasOne(OrangTua::class);
    }

    /** Kelas yang diampu user ini sebagai wali kelas (null jika bukan). */
    public function kelasWali(): ?Kelas
    {
        $guru = $this->guru;
        return $guru ? Kelas::where('wali_kelas_id', $guru->id)->first() : null;
    }
}