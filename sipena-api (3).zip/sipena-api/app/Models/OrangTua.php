<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrangTua extends Model
{
    protected $table = 'orang_tua';
    protected $guarded = ['id'];

    public function user() { return $this->belongsTo(User::class); }
    public function siswa() { return $this->hasMany(Siswa::class, 'ortu_id'); }
    public function notifikasi() { return $this->hasMany(Notifikasi::class, 'ortu_id'); }
}
