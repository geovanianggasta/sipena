<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    protected $table = 'guru';
    protected $guarded = ['id'];

    public function user() { return $this->belongsTo(User::class); }
    public function kelasWali() { return $this->hasMany(Kelas::class, 'wali_kelas_id'); }
    public function jadwal() { return $this->hasMany(Jadwal::class); }
}
