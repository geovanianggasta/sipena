<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notifikasi extends Model
{
    protected $table = 'notifikasi';
    protected $guarded = ['id'];

    public function ortu() { return $this->belongsTo(OrangTua::class, 'ortu_id'); }
    public function siswa() { return $this->belongsTo(Siswa::class); }
}
