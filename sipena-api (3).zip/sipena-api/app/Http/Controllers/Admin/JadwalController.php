<?php

namespace App\Http\Controllers\Admin;

use App\Models\Jadwal;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

// UC-27, 28, 29
class JadwalController extends CrudController
{
    protected array $with = ['kelas:id,nama_kelas', 'guru:id,nama'];
    protected array $searchable = ['mata_pelajaran'];

    protected function model(): string { return Jadwal::class; }

    protected function filter($q, Request $r): void
    {
        foreach (['kelas_id', 'guru_id', 'hari'] as $f) {
            if ($v = $r->query($f)) {
                $q->where($f, $v);
            }
        }
    }

    protected function rules(?int $id = null): array
    {
        return [
            'kelas_id' => ['required', 'exists:kelas,id'],
            'guru_id' => ['required', 'exists:guru,id'],
            'mata_pelajaran' => ['required', 'string', 'max:100'],
            'hari' => ['required', Rule::in(['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'])],
            'jam_mulai' => ['required', 'date_format:H:i'],
            'jam_selesai' => ['required', 'date_format:H:i', 'after:jam_mulai'],
        ];
    }

    private function t(string $v): string
    {
        return strlen($v) === 5 ? "$v:00" : $v;
    }

    // Jadwal bentrok: guru atau kelas sama, hari sama, jam beririsan
    protected function extraCheck(array $d, ?int $id): ?string
    {
        $mulai = $this->t($d['jam_mulai']);
        $selesai = $this->t($d['jam_selesai']);

        $q = fn() => Jadwal::where('hari', $d['hari'])
            ->when($id, fn($x) => $x->where('id', '!=', $id))
            ->where('jam_mulai', '<', $selesai)->where('jam_selesai', '>', $mulai);

        if ($q()->where('guru_id', $d['guru_id'])->exists()) {
            return 'Jadwal bentrok: guru sudah mengajar pada jam tersebut.';
        }
        if ($q()->where('kelas_id', $d['kelas_id'])->exists()) {
            return 'Jadwal bentrok: kelas sudah memiliki pelajaran pada jam tersebut.';
        }
        return null;
    }

    protected function guard(Model $m): ?string
    {
        return $m->presensi()->exists() ? 'Jadwal masih terkait dengan data presensi.' : null;
    }
}
