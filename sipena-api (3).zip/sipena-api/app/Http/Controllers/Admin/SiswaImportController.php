<?php

namespace App\Http\Controllers\Admin;

use App\Exports\TemplateSiswaExport;
use App\Http\Controllers\Controller;
use App\Imports\SiswaImport;
use App\Models\Kelas;
use App\Models\Siswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

// UC-30. Kolom file: nisn, nama, kelas (nama kelas, mis. 6A)
class SiswaImportController extends Controller
{
    public function template()
    {
        return Excel::download(new TemplateSiswaExport, 'template-siswa.xlsx');
    }

    private function baca(Request $r): array
    {
        $r->validate(['file' => 'required|file|mimes:xlsx,xls,csv,txt|max:5120']);

        try {
            $rows = Excel::toCollection(new SiswaImport, $r->file('file'))->first() ?? collect();
        } catch (\Throwable $e) {
            abort(422, 'File tidak bisa dibaca. Gunakan template Excel/CSV.');
        }
        if ($rows->isEmpty() || !$rows->first()->has('nisn') || !$rows->first()->has('nama') || !$rows->first()->has('kelas')) {
            abort(422, 'Format kolom tidak sesuai. Kolom wajib: nisn, nama, kelas.');
        }

        $kelas = Kelas::pluck('id', 'nama_kelas');
        $adaDb = Siswa::pluck('nisn')->flip();
        $lihat = [];
        $hasil = [];

        foreach ($rows as $i => $row) {
            $nisn = trim((string) ($row['nisn'] ?? ''));
            $nama = trim((string) ($row['nama'] ?? ''));
            $nk = trim((string) ($row['kelas'] ?? ''));
            $err = null;

            if ($nisn === '' || $nama === '' || $nk === '') $err = 'Data tidak lengkap.';
            elseif (strlen($nisn) > 20) $err = 'NISN terlalu panjang.';
            elseif (!isset($kelas[$nk])) $err = "Kelas '$nk' tidak ditemukan.";
            elseif (isset($adaDb[$nisn])) $err = 'NISN sudah terdaftar.';
            elseif (isset($lihat[$nisn])) $err = 'NISN duplikat di dalam file.';

            $lihat[$nisn] = true;
            $hasil[] = [
                'baris' => $i + 2, 'nisn' => $nisn, 'nama' => $nama, 'kelas' => $nk,
                'kelas_id' => $kelas[$nk] ?? null, 'valid' => $err === null, 'error' => $err,
            ];
        }
        return $hasil;
    }

    // Pratinjau: tidak menyimpan apa pun
    public function pratinjau(Request $r)
    {
        $h = $this->baca($r);
        return ['total' => count($h), 'valid' => count(array_filter($h, fn($x) => $x['valid'])), 'data' => $h];
    }

    // Simpan semua baris yang valid
    public function impor(Request $r)
    {
        $h = $this->baca($r);
        $valid = array_filter($h, fn($x) => $x['valid']);

        DB::transaction(function () use ($valid) {
            foreach ($valid as $x) {
                Siswa::create(['nisn' => $x['nisn'], 'nama' => $x['nama'], 'kelas_id' => $x['kelas_id']]);
            }
        });

        return [
            'message' => 'Impor selesai.',
            'berhasil' => count($valid),
            'gagal' => count($h) - count($valid),
            'detail_gagal' => array_values(array_filter($h, fn($x) => !$x['valid'])),
        ];
    }
}
