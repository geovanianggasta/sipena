<?php

namespace App\Http\Controllers\Admin;

use App\Models\OrangTua;
use App\Models\Siswa;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

// UC-24, 25, 26
class OrangTuaController extends CrudController
{
    protected array $with = ['siswa:id,nama,ortu_id', 'user:id,username'];
    protected array $searchable = ['nama', 'no_hp'];

    protected function model(): string { return OrangTua::class; }

    protected function rules(?int $id = null): array
    {
        return [
            'nama' => ['required', 'string', 'max:100'],
            'hubungan' => ['nullable', 'string', 'max:30'],
            'no_hp' => ['required', 'regex:/^[0-9+\-\s]{8,20}$/'],
            'alamat' => ['nullable', 'string', 'max:255'],
            'user_id' => ['nullable', 'exists:users,id', Rule::unique('orang_tua', 'user_id')->ignore($id)],
            'siswa_ids' => ['nullable', 'array'],
            'siswa_ids.*' => ['integer', 'exists:siswa,id'],
        ];
    }

    protected function attrs(array $d): array
    {
        unset($d['siswa_ids']);
        return $d;
    }

    // "siswa terkait": hubungkan siswa ke orang tua ini
    protected function afterSave(Model $m, array $d): void
    {
        if (array_key_exists('siswa_ids', $d)) {
            Siswa::where('ortu_id', $m->id)->update(['ortu_id' => null]);
            Siswa::whereIn('id', $d['siswa_ids'] ?? [])->update(['ortu_id' => $m->id]);
        }
    }

    protected function guard(Model $m): ?string
    {
        return $m->siswa()->exists() ? 'Data masih terkait dengan siswa. Lepaskan keterkaitan terlebih dahulu.' : null;
    }
}
