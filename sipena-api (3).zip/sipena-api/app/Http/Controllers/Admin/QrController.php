<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Siswa;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

// UC-31
class QrController extends Controller
{
    private function svg(string $token): string
    {
        return (string) QrCode::format('svg')->size(300)->margin(1)->generate($token);
    }

    // QR satu siswa (pratinjau)
    public function siswa($id)
    {
        $s = Siswa::findOrFail($id);
        return response($this->svg($s->qr_code), 200, ['Content-Type' => 'image/svg+xml']);
    }

    // PDF kartu: ?siswa_id=1 atau ?kelas_id=2
    public function kartu(Request $r)
    {
        $d = $r->validate(['siswa_id' => 'nullable|exists:siswa,id', 'kelas_id' => 'nullable|exists:kelas,id']);
        if (empty($d['siswa_id']) && empty($d['kelas_id'])) {
            return response()->json(['message' => 'Pilih siswa_id atau kelas_id.'], 422);
        }

        $siswa = Siswa::with('kelas:id,nama_kelas')
            ->when($d['siswa_id'] ?? null, fn($q, $v) => $q->where('id', $v))
            ->when($d['kelas_id'] ?? null, fn($q, $v) => $q->where('kelas_id', $v))
            ->orderBy('nama')->get();

        try {
            $kartu = $siswa->map(fn($s) => [
                'nama' => $s->nama, 'nisn' => $s->nisn, 'kelas' => $s->kelas?->nama_kelas,
                'svg' => base64_encode($this->svg($s->qr_code)),
            ]);
            return Pdf::loadView('laporan.kartu_qr', compact('kartu'))->setPaper('a4')->download('kartu-qr.pdf');
        } catch (\Throwable $e) {
            report($e);
            return response()->json(['message' => 'Gagal membuat kartu QR.'], 500);
        }
    }
}
