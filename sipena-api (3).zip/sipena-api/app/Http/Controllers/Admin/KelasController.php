<?php

namespace App\Http\Controllers\Admin;

use App\Models\Kelas;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

// UC-21, 22, 23
class KelasController extends CrudController
{
    protected array $with = ['waliKelas:id,nama'];
    protected array $searchable = ['nama_kelas'];

    protected function model(): string { return Kelas::class; }

    protected function rules(?int $id = null): array
    {
        return [
            'nama_kelas' => ['required', 'string', 'max:30', Rule::unique('kelas', 'nama_kelas')->ignore($id)],
            'tingkat' => ['required', 'integer', 'between:1,6'],
            'wali_kelas_id' => ['nullable', 'exists:guru,id', Rule::unique('kelas', 'wali_kelas_id')->ignore($id)],
            'tahun_ajaran' => ['required', 'regex:/^\d{4}\/\d{4}$/'],
        ];
    }

    protected function guard(Model $m): ?string
    {
        return ($m->siswa()->exists() || $m->jadwal()->exists())
            ? 'Kelas masih memiliki siswa atau jadwal.' : null;
    }
}
