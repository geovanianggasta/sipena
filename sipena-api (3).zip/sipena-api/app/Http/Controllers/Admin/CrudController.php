<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

abstract class CrudController extends Controller
{
    /** @return class-string<Model> */
    abstract protected function model(): string;
    abstract protected function rules(?int $id = null): array;

    protected array $with = [];
    protected array $searchable = [];

    protected function filter($query, Request $r): void {}
    protected function guard(Model $m): ?string { return null; }          // pesan jika tidak boleh dihapus
    protected function extraCheck(array $d, ?int $id): ?string { return null; } // pesan jika data bentrok
    protected function attrs(array $d): array { return $d; }              // data yang masuk ke model
    protected function afterSave(Model $m, array $d): void {}

    public function index(Request $r)
    {
        $q = ($this->model())::query()->with($this->with);
        if ($s = $r->query('q')) {
            $q->where(function ($w) use ($s) {
                foreach ($this->searchable as $c) {
                    $w->orWhere($c, 'like', "%$s%");
                }
            });
        }
        $this->filter($q, $r);
        return $q->orderByDesc('id')->paginate(min((int) $r->query('per_page', 20), 100));
    }

    public function show($id)
    {
        return ($this->model())::with($this->with)->findOrFail($id);
    }

    public function store(Request $r)
    {
        $d = $r->validate($this->rules());
        if ($msg = $this->extraCheck($d, null)) {
            return $this->bentrok($msg);
        }
        $m = ($this->model())::create($this->attrs($d));
        $this->afterSave($m, $d);
        return response()->json($m->fresh($this->with), 201);
    }

    public function update(Request $r, $id)
    {
        $m = ($this->model())::findOrFail($id);
        $rules = $this->rules($m->id);
        if ($r->isMethod('patch')) {
            $rules = array_map(fn($x) => array_merge(['sometimes'], (array) $x), $rules);
        }
        $d = $r->validate($rules);
        if ($msg = $this->extraCheck(array_merge($m->toArray(), $d), $m->id)) {
            return $this->bentrok($msg);
        }
        $m->update($this->attrs($d));
        $this->afterSave($m, $d);
        return $m->fresh($this->with);
    }

    public function destroy(Request $r, $id)
    {
        $m = ($this->model())::findOrFail($id);
        if ($msg = $this->guard($m)) {
            return response()->json(['message' => $msg], 409);
        }
        $m->delete();
        return response()->json(['message' => 'Data berhasil dihapus.']);
    }

    private function bentrok(string $msg)
    {
        return response()->json(['message' => $msg, 'errors' => ['data' => [$msg]]], 422);
    }
}
