<?php

namespace App\Http\Controllers\Admin;

use App\Models\Guru;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

// UC-18, 19, 20
class GuruController extends CrudController
{
    protected array $with = ['user:id,username,role'];
    protected array $searchable = ['nama', 'nip'];

    protected function model(): string { return Guru::class; }

    protected function rules(?int $id = null): array
    {
        return [
            'nip' => ['required', 'string', 'max:30', Rule::unique('guru', 'nip')->ignore($id)],
            'nama' => ['required', 'string', 'max:100'],
            'mata_pelajaran' => ['nullable', 'string', 'max:100'],
            'kontak' => ['nullable', 'string', 'max:30'],
            'user_id' => ['nullable', 'exists:users,id', Rule::unique('guru', 'user_id')->ignore($id)],
        ];
    }

    protected function guard(Model $m): ?string
    {
        return ($m->kelasWali()->exists() || $m->jadwal()->exists())
            ? 'Guru masih terkait dengan kelas (wali kelas) atau jadwal.' : null;
    }
}
