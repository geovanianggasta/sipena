<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

// UC-12, 13, 14
class UserController extends CrudController
{
    protected array $searchable = ['name', 'username'];

    protected function model(): string { return User::class; }

    protected function filter($q, Request $r): void
    {
        if ($role = $r->query('role')) {
            $q->where('role', $role);
        }
    }

    protected function rules(?int $id = null): array
    {
        return [
            'name' => ['required', 'string', 'max:100'],
            'username' => ['required', 'string', 'max:50', 'alpha_dash', Rule::unique('users', 'username')->ignore($id)],
            'password' => $id ? ['nullable', 'string', 'min:6'] : ['required', 'string', 'min:6'],
            'role' => ['required', Rule::in(User::ROLES)],
        ];
    }

    protected function attrs(array $d): array
    {
        if (empty($d['password'])) {
            unset($d['password']);
        }
        return $d;
    }

    protected function guard(Model $m): ?string
    {
        if ($m->id === auth()->id()) {
            return 'Akun yang sedang dipakai tidak bisa dihapus.';
        }
        if ($m->guru()->exists() || $m->orangTua()->exists()) {
            return 'Akun masih terhubung dengan data guru/orang tua. Lepaskan keterkaitan terlebih dahulu.';
        }
        return null;
    }
}
