<?php

namespace App\Http\Controllers\Admin;

use App\Models\Siswa;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

// UC-15, 16, 17
class SiswaController extends CrudController
{
    protected array $with = ['kelas:id,nama_kelas', 'ortu:id,nama,no_hp'];
    protected array $searchable = ['nama', 'nisn'];

    protected function model(): string { return Siswa::class; }

    protected function filter($q, Request $r): void
    {
        if ($k = $r->query('kelas_id')) {
            $q->where('kelas_id', $k);
        }
    }

    protected function rules(?int $id = null): array
    {
        return [
            'nisn' => ['required', 'string', 'max:20', Rule::unique('siswa', 'nisn')->ignore($id)],
            'nama' => ['required', 'string', 'max:100'],
            'kelas_id' => ['required', 'exists:kelas,id'],
            'ortu_id' => ['nullable', 'exists:orang_tua,id'],
        ];
    }

    protected function guard(Model $m): ?string
    {
        return $m->presensi()->exists()
            ? 'Siswa memiliki riwayat kehadiran sehingga tidak bisa dihapus.' : null;
    }

    // Kartu hilang -> buat token QR baru (token lama otomatis tidak berlaku)
    public function regenerateQr($id)
    {
        $s = Siswa::findOrFail($id);
        $s->update(['qr_code' => Siswa::tokenBaru()]);
        return ['message' => 'QR baru dibuat. Cetak ulang kartu siswa.'];
    }
}
