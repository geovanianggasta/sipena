<?php

namespace App\Http\Controllers;

use App\Models\Presensi;
use App\Models\Siswa;
use Illuminate\Http\Request;

class OrtuController extends Controller
{
    private function ortu(Request $r)
    {
        return $r->user()->orangTua ?? abort(403, 'Akun belum terhubung dengan data orang tua/wali.');
    }

    // UC-09: status hari ini untuk tiap anak
    public function anak(Request $r)
    {
        $hari = now()->toDateString();
        $anak = Siswa::with(['kelas:id,nama_kelas', 'presensi' => fn($q) => $q->where('tanggal', $hari)])
            ->where('ortu_id', $this->ortu($r)->id)->get()
            ->map(fn($s) => [
                'siswa_id' => $s->id, 'nama' => $s->nama, 'nisn' => $s->nisn, 'kelas' => $s->kelas?->nama_kelas,
                'hari_ini' => $s->presensi->first(),
            ]);
        return ['tanggal' => $hari, 'data' => $anak];
    }

    // UC-09 langkah 4: rekap bulanan (?bulan=YYYY-MM)
    public function rekap(Request $r, $siswaId)
    {
        $d = $r->validate(['bulan' => 'nullable|date_format:Y-m']);
        $siswa = Siswa::where('id', $siswaId)->where('ortu_id', $this->ortu($r)->id)->first();
        if (!$siswa) {
            return response()->json(['message' => 'Data siswa tidak ditemukan pada akun Anda.'], 403);
        }

        $bulan = \Carbon\Carbon::createFromFormat('Y-m-d', ($d['bulan'] ?? now()->format('Y-m')) . '-01');
        $rows = Presensi::where('siswa_id', $siswa->id)
            ->whereBetween('tanggal', [$bulan->toDateString(), $bulan->copy()->endOfMonth()->toDateString()])
            ->orderBy('tanggal')->get(['id', 'tanggal', 'waktu_scan', 'status', 'keterangan']);

        $ringkas = [];
        foreach (Presensi::STATUS as $s) {
            $ringkas[$s] = $rows->where('status', $s)->count();
        }
        return ['bulan' => $bulan->format('Y-m'), 'siswa' => $siswa->nama, 'ringkasan' => $ringkas, 'data' => $rows];
    }

    public function notifikasi(Request $r)
    {
        return $this->ortu($r)->notifikasi()->latest('id')->paginate(20);
    }
}
