<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use App\Models\Kelas;
use App\Models\Presensi;
use App\Models\Siswa;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    private function hitungHari(string $tgl): array
    {
        $out = [];
        foreach (Presensi::STATUS as $s) {
            $out[$s] = Presensi::where('tanggal', $tgl)->where('status', $s)->count();
        }
        return $out;
    }

    public function index(Request $r)
    {
        $u = $r->user();
        $hariIni = now()->toDateString();

        return match ($u->role) {
            'guru', 'wali_kelas' => $this->guru($u, $hariIni),
            'kepala_sekolah' => $this->kepsek($hariIni),
            'admin' => $this->admin(),
            default => response()->json(['message' => 'Gunakan endpoint /ortu/anak.'], 404),
        };
    }

    private function guru(User $u, string $hariIni): array
    {
        $res = ['tanggal' => $hariIni, 'nama' => $u->name, 'statistik' => $this->hitungHari($hariIni)];
        if ($u->role === 'wali_kelas' && ($k = $u->kelasWali())) {
            $res['validasi_tertunda'] = Presensi::whereHas('siswa', fn($s) => $s->where('kelas_id', $k->id))
                ->where('status_validasi', false)->count();
        }
        return $res;
    }

    private function admin(): array
    {
        return [
            'jumlah_siswa' => Siswa::count(),
            'jumlah_guru' => Guru::count(),
            'jumlah_kelas' => Kelas::count(),
            'akun_orang_tua' => User::where('role', 'orang_tua')->count(),
        ];
    }

    // UC-11
    private function kepsek(string $hariIni): array
    {
        $awalBulan = now()->startOfMonth()->toDateString();

        $perKelas = Kelas::orderBy('nama_kelas')->get()->map(function ($k) use ($awalBulan, $hariIni) {
            $q = Presensi::whereHas('siswa', fn($s) => $s->where('kelas_id', $k->id))->whereBetween('tanggal', [$awalBulan, $hariIni]);
            $total = (clone $q)->count();
            $hadir = (clone $q)->where('status', 'hadir')->count();
            return ['kelas_id' => $k->id, 'kelas' => $k->nama_kelas, 'persentase_hadir' => $total ? round($hadir / $total * 100, 1) : 0];
        });

        $alpha = Siswa::with('kelas:id,nama_kelas')
            ->withCount(['presensi as alpha_30_hari' => fn($q) => $q->where('status', 'alpha')->where('tanggal', '>=', now()->subDays(30)->toDateString())])
            ->get()->filter(fn($s) => $s->alpha_30_hari >= 3)->values()
            ->map(fn($s) => ['siswa_id' => $s->id, 'nama' => $s->nama, 'kelas' => $s->kelas?->nama_kelas, 'alpha_30_hari' => $s->alpha_30_hari]);

        $tren = [];
        for ($i = 5; $i >= 0; $i--) {
            $m = now()->subMonths($i);
            $q = Presensi::whereBetween('tanggal', [$m->copy()->startOfMonth()->toDateString(), $m->copy()->endOfMonth()->toDateString()]);
            $total = (clone $q)->count();
            $hadir = (clone $q)->where('status', 'hadir')->count();
            $tren[] = ['bulan' => $m->format('Y-m'), 'persentase_hadir' => $total ? round($hadir / $total * 100, 1) : 0];
        }

        return array_merge(
            ['tanggal' => $hariIni, 'statistik_hari_ini' => $this->hitungHari($hariIni)],
            $this->admin(),
            ['persentase_per_kelas' => $perKelas, 'alpha_berulang' => $alpha, 'tren_bulanan' => $tren]
        );
    }
}
