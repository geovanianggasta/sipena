<?php

namespace App\Http\Controllers;

use App\Exports\RekapExport;
use App\Services\RekapService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class RekapController extends Controller
{
    public function __construct(private RekapService $svc) {}

    private function params(Request $r): array
    {
        $d = $r->validate([
            'dari' => 'nullable|date_format:Y-m-d',
            'sampai' => 'nullable|date_format:Y-m-d|after_or_equal:dari',
            'kelas_id' => 'nullable|exists:kelas,id',
            'siswa_id' => 'nullable|exists:siswa,id',
            'format' => 'nullable|in:pdf,xlsx',
        ]);
        return [
            $d['dari'] ?? now()->startOfMonth()->toDateString(),
            $d['sampai'] ?? now()->toDateString(),
            $d['kelas_id'] ?? null,
            $d['siswa_id'] ?? null,
            $d['format'] ?? 'pdf',
        ];
    }

    // UC-05
    public function index(Request $r)
    {
        [$dari, $sampai, $kelas, $siswa] = $this->params($r);
        $data = $this->svc->rekap($dari, $sampai, $kelas, $siswa);

        if ($data->isEmpty() || $data->sum('total') === 0) {
            return response()->json(['message' => 'Belum ada data kehadiran pada filter ini.', 'dari' => $dari, 'sampai' => $sampai, 'data' => []]);
        }
        return ['dari' => $dari, 'sampai' => $sampai, 'data' => $data];
    }

    // UC-08
    public function ekspor(Request $r)
    {
        [$dari, $sampai, $kelas, $siswa, $format] = $this->params($r);
        $rekap = $this->svc->rekap($dari, $sampai, $kelas, $siswa);
        $nama = "rekap-kehadiran-{$dari}-{$sampai}";

        try {
            return $format === 'xlsx'
                ? Excel::download(new RekapExport($rekap), "$nama.xlsx")
                : Pdf::loadView('laporan.rekap', compact('rekap', 'dari', 'sampai'))->setPaper('a4')->download("$nama.pdf");
        } catch (\Throwable $e) {
            report($e);
            return response()->json(['message' => 'Laporan gagal dibuat. Coba lagi.'], 500);
        }
    }
}
