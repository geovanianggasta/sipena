<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\PersonalAccessToken;

class AuthController extends Controller
{
    // UC-01
    public function login(Request $r)
    {
        $d = $r->validate(['username' => 'required|string', 'password' => 'required|string']);
        $user = User::where('username', $d['username'])->first();

        if (!$user || !Hash::check($d['password'], $user->password)) {
            return response()->json(['message' => 'Username atau password salah.'], 401);
        }

        return response()->json([
            'token' => $user->createToken('sipena')->plainTextToken,
            'user' => $user,
        ]);
    }

    // UC-02
    public function logout(Request $r)
    {
        $t = $r->user()->currentAccessToken();
        if ($t instanceof PersonalAccessToken) {
            $t->delete();
        }
        return response()->json(['message' => 'Berhasil keluar.']);
    }

    public function me(Request $r)
    {
        $u = $r->user();
        $u->load(['guru', 'orangTua']);
        return ['user' => $u, 'kelas_wali' => $u->kelasWali()];
    }

    public function fcmToken(Request $r)
    {
        $d = $r->validate(['fcm_token' => 'required|string|max:255']);
        $r->user()->update(['fcm_token' => $d['fcm_token']]);
        return response()->json(['message' => 'Token perangkat disimpan.']);
    }
}
