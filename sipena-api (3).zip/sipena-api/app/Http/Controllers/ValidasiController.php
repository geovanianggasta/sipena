<?php

namespace App\Http\Controllers;

use App\Models\Presensi;
use App\Services\PresensiService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ValidasiController extends Controller
{
    public function __construct(private PresensiService $svc) {}

    private function kelasWali(Request $r)
    {
        return $r->user()->kelasWali();
    }

    // UC-06 langkah 1: daftar absensi kelas yang belum divalidasi
    public function index(Request $r)
    {
        $kelas = $this->kelasWali($r);
        if (!$kelas) {
            return response()->json(['message' => 'Anda belum ditetapkan sebagai wali kelas.'], 403);
        }
        $d = $r->validate(['tanggal' => 'nullable|date_format:Y-m-d']);

        $q = Presensi::with('siswa:id,nisn,nama')
            ->whereHas('siswa', fn($s) => $s->where('kelas_id', $kelas->id))
            ->where('status_validasi', false)
            ->when($d['tanggal'] ?? null, fn($q, $v) => $q->where('tanggal', $v))
            ->orderBy('tanggal')->get();

        return ['kelas' => $kelas->nama_kelas, 'belum_divalidasi' => $q->count(), 'data' => $q];
    }

    // UC-06: validasi seluruh presensi kelas pada satu tanggal
    public function store(Request $r)
    {
        $kelas = $this->kelasWali($r);
        if (!$kelas) {
            return response()->json(['message' => 'Anda belum ditetapkan sebagai wali kelas.'], 403);
        }
        $d = $r->validate(['tanggal' => 'required|date_format:Y-m-d']);

        $jumlah = Presensi::whereHas('siswa', fn($s) => $s->where('kelas_id', $kelas->id))
            ->where('tanggal', $d['tanggal'])->where('status_validasi', false)
            ->update(['status_validasi' => true, 'validated_by' => $r->user()->id, 'validated_at' => now()]);

        if ($jumlah === 0) {
            return response()->json(['message' => 'Tidak ada data absensi yang perlu divalidasi pada tanggal tersebut.'], 422);
        }
        return ['message' => 'Validasi berhasil.', 'jumlah' => $jumlah];
    }

    // UC-07
    public function koreksi(Request $r, $id)
    {
        $kelas = $this->kelasWali($r);
        $p = Presensi::with('siswa.ortu.user')->findOrFail($id);

        if (!$kelas || $p->siswa->kelas_id !== $kelas->id) {
            return response()->json(['message' => 'Presensi ini bukan milik kelas Anda.'], 403);
        }
        $d = $r->validate([
            'status' => ['required', Rule::in(Presensi::STATUS)],
            'alasan' => 'required|string|max:255',
        ]);

        return ['message' => 'Koreksi berhasil.', 'presensi' => $this->svc->koreksi($p, $d['status'], $d['alasan'], $r->user())->load('log')];
    }
}
