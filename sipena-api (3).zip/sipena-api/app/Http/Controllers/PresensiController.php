<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Models\Presensi;
use App\Models\Siswa;
use App\Services\PresensiService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PresensiController extends Controller
{
    public function __construct(private PresensiService $svc) {}

    public function kelasOpsi()
    {
        return Kelas::orderBy('nama_kelas')->get(['id', 'nama_kelas', 'tingkat']);
    }

    // Daftar siswa + status hari itu (halaman Absensi). Siswa tanpa presensi => presensi: null
    public function index(Request $r)
    {
        $d = $r->validate([
            'tanggal' => 'nullable|date_format:Y-m-d',
            'kelas_id' => 'nullable|exists:kelas,id',
            'q' => 'nullable|string|max:100',
        ]);
        $tgl = $d['tanggal'] ?? now()->toDateString();

        $siswa = Siswa::query()
            ->with(['kelas:id,nama_kelas', 'presensi' => fn($q) => $q->where('tanggal', $tgl)])
            ->when($d['kelas_id'] ?? null, fn($q, $v) => $q->where('kelas_id', $v))
            ->when($d['q'] ?? null, fn($q, $v) => $q->where(fn($w) => $w->where('nama', 'like', "%$v%")->orWhere('nisn', 'like', "%$v%")))
            ->orderBy('nama')->get()
            ->map(fn($s) => [
                'siswa_id' => $s->id, 'nisn' => $s->nisn, 'nama' => $s->nama,
                'kelas' => $s->kelas?->nama_kelas,
                'presensi' => $s->presensi->first(),
            ]);

        return ['tanggal' => $tgl, 'data' => $siswa];
    }

    // UC-03
    public function scan(Request $r)
    {
        $d = $r->validate(['qr_code' => 'required|string|max:100', 'jadwal_id' => 'nullable|exists:jadwal,id']);

        $siswa = Siswa::with(['kelas:id,nama_kelas', 'ortu.user'])->where('qr_code', $d['qr_code'])->first();
        if (!$siswa) {
            return response()->json(['message' => 'QR tidak valid atau tidak terdaftar.'], 404);
        }

        [$p, $hasil] = $this->svc->catat($siswa, 'hadir', null, now()->toDateString(), $d['jadwal_id'] ?? null, false);

        return response()->json([
            'message' => $hasil === 'sudah_ada' ? "{$siswa->nama} sudah tercatat {$p->status} hari ini." : "{$siswa->nama} tercatat hadir.",
            'hasil' => $hasil,
            'siswa' => ['id' => $siswa->id, 'nama' => $siswa->nama, 'nisn' => $siswa->nisn, 'kelas' => $siswa->kelas?->nama_kelas],
            'presensi' => $p,
        ], $hasil === 'baru' ? 201 : 200);
    }

    // UC-04
    public function manual(Request $r)
    {
        $d = $r->validate([
            'siswa_id' => 'required|exists:siswa,id',
            'status' => ['required', Rule::in(Presensi::STATUS)],
            'keterangan' => 'nullable|string|max:255',
            'tanggal' => 'nullable|date_format:Y-m-d|before_or_equal:today',
            'jadwal_id' => 'nullable|exists:jadwal,id',
        ]);

        $siswa = Siswa::with('ortu.user')->findOrFail($d['siswa_id']);
        [$p, $hasil] = $this->svc->catat($siswa, $d['status'], $d['keterangan'] ?? null, $d['tanggal'] ?? now()->toDateString(), $d['jadwal_id'] ?? null, true);

        return response()->json(['message' => 'Presensi tersimpan.', 'hasil' => $hasil, 'presensi' => $p], $hasil === 'baru' ? 201 : 200);
    }
}
