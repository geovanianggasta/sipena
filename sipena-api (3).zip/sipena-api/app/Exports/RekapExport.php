<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class RekapExport implements FromCollection, WithHeadings
{
    public function __construct(private Collection $rekap) {}

    public function headings(): array
    {
        return ['NISN', 'Nama', 'Kelas', 'Hadir', 'Izin', 'Sakit', 'Alpha', 'Total', 'Persentase Hadir (%)'];
    }

    public function collection(): Collection
    {
        return $this->rekap->map(fn($r) => [
            $r['nisn'], $r['nama'], $r['kelas'], $r['hadir'], $r['izin'], $r['sakit'], $r['alpha'], $r['total'], $r['persentase_hadir'],
        ]);
    }
}
