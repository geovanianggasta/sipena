<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;

class TemplateSiswaExport implements FromArray, WithHeadings
{
    public function headings(): array { return ['nisn', 'nama', 'kelas']; }
    public function array(): array { return [['0012345678', 'Contoh Nama Siswa', '6A']]; }
}
