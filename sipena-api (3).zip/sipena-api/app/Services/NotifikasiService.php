<?php

namespace App\Services;

use App\Models\Notifikasi;
use App\Models\Presensi;
use App\Models\Siswa;
use Throwable;

class NotifikasiService
{
    public function __construct(private PushSender $push) {}

    /** UC-10: kirim notifikasi ke orang tua. Tidak pernah melempar error ke pemanggil. */
    public function presensi(Siswa $siswa, Presensi $p, ?string $statusLama = null): ?Notifikasi
    {
        try {
            $ortu = $siswa->ortu;
            $tgl = date('d-m-Y', strtotime($p->tanggal));

            $pesan = $statusLama
                ? "Status kehadiran {$siswa->nama} pada {$tgl} dikoreksi dari {$statusLama} menjadi {$p->status}."
                : "{$siswa->nama} tercatat {$p->status} pada {$tgl}" . ($p->waktu_scan ? " pukul " . substr($p->waktu_scan, 0, 5) : '') . '.';

            $n = Notifikasi::create([
                'siswa_id' => $siswa->id,
                'ortu_id' => $ortu?->id,
                'pesan' => $pesan,
                'tanggal' => now(),
                'status_kirim' => 'menunggu',
            ]);

            // Alternatif A1: kontak orang tua tidak tersedia -> catat gagal
            if (!$ortu || !$ortu->no_hp) {
                $n->update(['status_kirim' => 'gagal']);
                return $n;
            }

            $token = $ortu->user?->fcm_token;
            $ok = $token ? $this->push->send($token, 'Kehadiran Siswa', $pesan) : true; // tanpa token: tetap tampil di aplikasi
            $n->update(['status_kirim' => $ok ? 'terkirim' : 'gagal']);
            return $n;
        } catch (Throwable $e) {
            report($e);
            return null;
        }
    }
}
