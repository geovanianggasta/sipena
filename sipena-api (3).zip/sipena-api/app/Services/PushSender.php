<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;

/**
 * Pengirim push notification. Saat ini hanya menulis ke log.
 * Ganti isi send() dengan FCM (mis. paket kreait/laravel-firebase) saat siap.
 */
class PushSender
{
    public function send(string $fcmToken, string $judul, string $isi): bool
    {
        Log::info('PUSH', compact('fcmToken', 'judul', 'isi'));
        return true;
    }
}
