<?php

namespace App\Services;

use App\Models\Siswa;
use Illuminate\Support\Collection;

class RekapService
{
    /** Rekap H/I/S/A + persentase hadir per siswa pada rentang tanggal. */
    public function rekap(string $dari, string $sampai, ?int $kelasId = null, ?int $siswaId = null): Collection
    {
        $hitung = fn(string $st) => fn($q) => $q->where('status', $st)->whereBetween('tanggal', [$dari, $sampai]);

        return Siswa::query()
            ->with('kelas:id,nama_kelas')
            ->when($kelasId, fn($q) => $q->where('kelas_id', $kelasId))
            ->when($siswaId, fn($q) => $q->where('id', $siswaId))
            ->withCount([
                'presensi as hadir' => $hitung('hadir'),
                'presensi as izin' => $hitung('izin'),
                'presensi as sakit' => $hitung('sakit'),
                'presensi as alpha' => $hitung('alpha'),
            ])
            ->orderBy('nama')
            ->get()
            ->map(function ($s) {
                $total = $s->hadir + $s->izin + $s->sakit + $s->alpha;
                return [
                    'siswa_id' => $s->id,
                    'nisn' => $s->nisn,
                    'nama' => $s->nama,
                    'kelas' => $s->kelas?->nama_kelas,
                    'hadir' => $s->hadir,
                    'izin' => $s->izin,
                    'sakit' => $s->sakit,
                    'alpha' => $s->alpha,
                    'total' => $total,
                    'persentase_hadir' => $total ? round($s->hadir / $total * 100, 1) : 0,
                ];
            });
    }
}
