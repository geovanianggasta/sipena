<?php

namespace App\Services;

use App\Models\LogPerubahan;
use App\Models\Presensi;
use App\Models\Siswa;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PresensiService
{
    public function __construct(private NotifikasiService $notif) {}

    /**
     * Catat presensi. $timpa=false (scan): jika sudah ada, tidak diubah.
     * Return [Presensi, 'baru'|'diubah'|'sudah_ada'].
     */
    public function catat(Siswa $siswa, string $status, ?string $ket, string $tanggal, ?int $jadwalId, bool $timpa): array
    {
        $ada = Presensi::where('siswa_id', $siswa->id)->where('tanggal', $tanggal)->first();

        if ($ada && !$timpa) {
            return [$ada, 'sudah_ada'];
        }
        if ($ada && $ada->status_validasi) {
            throw ValidationException::withMessages([
                'siswa_id' => 'Presensi sudah divalidasi wali kelas. Gunakan koreksi status.',
            ]);
        }

        if ($ada) {
            $lama = $ada->status;
            $ada->update(['status' => $status, 'keterangan' => $ket, 'jadwal_id' => $jadwalId ?? $ada->jadwal_id, 'waktu_scan' => now()->format('H:i:s')]);
            if ($lama !== $status) {
                $this->notif->presensi($siswa, $ada);
            }
            return [$ada->fresh(), 'diubah'];
        }

        $p = Presensi::create([
            'siswa_id' => $siswa->id,
            'jadwal_id' => $jadwalId,
            'tanggal' => $tanggal,
            'waktu_scan' => now()->format('H:i:s'),
            'status' => $status,
            'keterangan' => $ket,
        ]);
        $this->notif->presensi($siswa, $p);
        return [$p, 'baru'];
    }

    /** UC-07: koreksi status + log perubahan (include). */
    public function koreksi(Presensi $p, string $statusBaru, string $alasan, User $oleh): Presensi
    {
        if ($p->status === $statusBaru) {
            throw ValidationException::withMessages(['status' => 'Status baru sama dengan status saat ini.']);
        }

        $lama = $p->status;
        DB::transaction(function () use ($p, $statusBaru, $alasan, $oleh, $lama) {
            $p->update(['status' => $statusBaru, 'keterangan' => $alasan]);
            LogPerubahan::create([
                'presensi_id' => $p->id,
                'pengguna_id' => $oleh->id,
                'waktu' => now(),
                'status_lama' => $lama,
                'status_baru' => $statusBaru,
                'alasan' => $alasan,
            ]);
        });

        $this->notif->presensi($p->siswa, $p->fresh(), $lama);
        return $p->fresh();
    }
}
