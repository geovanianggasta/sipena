<?php
require __DIR__ . '/config.php';
$pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS);
$st = $pdo->prepare("INSERT IGNORE INTO users (username, password, nama, role) VALUES ('admin', ?, 'Admin SIPENA', 'admin')");
$st->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
echo "Akun admin dibuat: admin / admin123 (segera ganti passwordnya)\n";
