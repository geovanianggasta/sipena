<?php
require __DIR__ . '/core.php';
foreach (['auth', 'presensi', 'laporan', 'master'] as $c) {
    require __DIR__ . "/controllers/$c.php";
}
dispatch();
